/**
 * 供 chrome.scripting.executeScript 序列化注入到页面 MAIN 的纯函数。
 * 禁止加入 build-store 混淆：混淆体会引用 SW 内 stringArray 等辅助函数，目标页不存在 → 注入失败（dom_extract_failed / page_replay_failed）。
 */
globalThis.hx0DomPostFormSubmitInPage = function hx0DomPostFormSubmitInPage(actionUrl, pairs) {
  try {
    var f = document.createElement('form');
    f.method = 'POST';
    f.action = actionUrl;
    f.enctype = 'application/x-www-form-urlencoded';
    f.style.display = 'none';
    for (var i = 0; i < pairs.length; i++) {
      var inp = document.createElement('input');
      inp.type = 'hidden';
      inp.name = pairs[i].name;
      inp.value = pairs[i].value;
      f.appendChild(inp);
    }
    (document.body || document.documentElement).appendChild(f);
    f.submit();
    return true;
  } catch (e) {
    return false;
  }
};

globalThis.hx0DomPostIframeInPage = function hx0DomPostIframeInPage(actionUrl, pairs, decryptWaitMs) {
  return new Promise(function (resolve) {
    var done = false;
    function finish(ok, body, err) {
      if (done) return;
      done = true;
      if (ok) resolve({ ok: true, body: body || '' });
      else resolve({ ok: false, error: err || 'unknown' });
    }
    try {
      var iframe = document.createElement('iframe');
      iframe.name = 'hx0_dom_post_' + Date.now();
      iframe.style.cssText = 'position:fixed;width:1px;height:1px;left:-9999px;top:0;visibility:hidden;';
      var form = document.createElement('form');
      form.method = 'POST';
      form.action = actionUrl;
      form.target = iframe.name;
      form.enctype = 'application/x-www-form-urlencoded';
      form.style.display = 'none';
      for (var j = 0; j < pairs.length; j++) {
        var inp2 = document.createElement('input');
        inp2.type = 'hidden';
        inp2.name = pairs[j].name;
        inp2.value = pairs[j].value;
        form.appendChild(inp2);
      }
      document.body.appendChild(iframe);
      document.body.appendChild(form);
      iframe.onload = function () {
        setTimeout(function () {
          try {
            var doc = iframe.contentDocument;
            var html = doc && doc.documentElement ? doc.documentElement.outerHTML : '';
            iframe.remove();
            finish(true, html);
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            finish(false, '', String(e));
          }
        }, Math.min(decryptWaitMs, 5000));
      };
      form.submit();
      try {
        form.remove();
      } catch (e) {}
      setTimeout(function () {
        if (done) return;
        if (iframe.parentNode) {
          try {
            var doc2 = iframe.contentDocument;
            var html2 = doc2 && doc2.documentElement ? doc2.documentElement.outerHTML : '';
            iframe.remove();
            finish(true, html2);
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            finish(false, '', 'Timeout or cross-origin');
          }
        }
      }, 20000);
    } catch (e) {
      finish(false, '', String(e));
    }
  });
};

globalThis.hx0DomExtractInPage = function hx0DomExtractInPage(url, useIframe, decryptWaitMs) {
  return new Promise(function (resolve) {
    try {
      if (useIframe) {
        var iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:fixed;width:1px;height:1px;left:-9999px;top:0;visibility:hidden;';
        iframe.src = url;
        document.body.appendChild(iframe);
        var doExtract = function () {
          try {
            var doc = iframe.contentDocument;
            var html = doc && doc.documentElement ? doc.documentElement.outerHTML : '';
            iframe.remove();
            resolve({ ok: true, body: html });
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            resolve({ ok: false, error: String(e) });
          }
        };
        iframe.onload = function () {
          setTimeout(doExtract, Math.min(decryptWaitMs, 5000));
        };
        setTimeout(function () {
          if (iframe.parentNode) {
            try {
              var doc2 = iframe.contentDocument;
              var html2 = doc2 && doc2.documentElement ? doc2.documentElement.outerHTML : '';
              iframe.remove();
              resolve({ ok: true, body: html2 });
            } catch (e) {
              try {
                iframe.remove();
              } catch (err) {}
              resolve({ ok: false, error: 'Timeout or cross-origin' });
            }
          }
        }, 20000);
      } else {
        var html3 = document.documentElement ? document.documentElement.outerHTML : '';
        resolve({ ok: true, body: html3 });
      }
    } catch (e) {
      resolve({ ok: false, error: String(e) });
    }
  });
};

/** 页面上下文重放：在激活 Tab 内 fetch（与 background fetch 同源策略不同） */
globalThis.hx0PageContextReplayFetch = async function hx0PageContextReplayFetch(u, p) {
  try {
    var method = String((p && p.method) || 'GET').toUpperCase();
    var methodAutoFixed = !!p.methodAutoFixed;
    var body;
    if (p.bodyB64) {
      var bin = atob(p.bodyB64);
      var out = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
      body = out;
    } else {
      body = undefined;
    }
    if ((method === 'GET' || method === 'HEAD') && body !== undefined && body.byteLength > 0) {
      method = 'POST';
      methodAutoFixed = true;
    }
    var r = await fetch(u, {
      method: method,
      headers: p.headers || {},
      body: body,
      credentials: 'include',
      redirect: 'follow',
      cache: 'no-store',
    });
    var responseBody = await r.text();
    var headers = {};
    r.headers.forEach(function (v, k) {
      headers[k] = v;
    });
    return { ok: true, status: r.status, headers: headers, body: responseBody, methodAutoFixed: methodAutoFixed, methodSent: method };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
};

/** Firefox 页面内 DOM 提取：同步返回当前文档 HTML（无 iframe 分支） */
globalThis.hx0DomExtractOuterHtmlSync = function hx0DomExtractOuterHtmlSync() {
  try {
    return document.documentElement ? document.documentElement.outerHTML : '';
  } catch (e) {
    return '';
  }
};
