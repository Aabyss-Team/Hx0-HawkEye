/**
 * 油猴/Tampermonkey 用户脚本兼容：元数据解析 + 常用 GM_* API 垫片。
 * 供 background（importScripts）与 sidepanel（script src）共用。
 */
(function (g) {
  'use strict';

  function parseTampermonkeyHeader(code) {
    const raw = String(code || '');
    const m = raw.match(/^\s*(\/\/\s*==UserScript==[\s\S]*?\/\/\s*==\/UserScript==\s*\r?\n?)/);
    if (!m) return { hasMeta: false, header: '', body: raw, meta: null };
    const header = m[1];
    const body = raw.slice(m[0].length);
    const meta = {
      name: '',
      namespace: '',
      version: '',
      description: '',
      grants: [],
      requires: [],
      matches: [],
      includes: [],
      excludes: [],
      connects: [],
      resources: [],
      noframes: false,
      runAt: 'document_idle',
      downloadURL: '',
      updateURL: '',
      supportURL: '',
      homepageURL: '',
      author: '',
      license: '',
    };
    header.split(/\r?\n/).forEach((line) => {
      const row = line.match(/^\s*\/\/\s*@([\w-]+)\s+(.*)$/);
      if (!row) return;
      const key = String(row[1] || '').toLowerCase();
      const val = String(row[2] || '').trim();
      if (key === 'grant') meta.grants.push(val);
      else if (key === 'require') meta.requires.push(val);
      else if (key === 'match') meta.matches.push(val);
      else if (key === 'include') meta.includes.push(val);
      else if (key === 'exclude') meta.excludes.push(val);
      else if (key === 'connect') meta.connects.push(val);
      else if (key === 'resource') {
        const parts = val.match(/^(\S+)\s+(.+)$/);
        if (parts) meta.resources.push({ name: parts[1], url: parts[2].trim() });
      }
      else if (key === 'noframes') meta.noframes = true;
      else if (key === 'name') meta.name = val;
      else if (key === 'namespace') meta.namespace = val;
      else if (key === 'version') meta.version = val;
      else if (key === 'description') meta.description = val;
      else if (key === 'run-at') {
        if (/document-start/i.test(val)) meta.runAt = 'document_start';
        else if (/document-end/i.test(val)) meta.runAt = 'document_end';
        else meta.runAt = 'document_idle';
      }
      else if (key === 'downloadurl') meta.downloadURL = val;
      else if (key === 'updateurl') meta.updateURL = val;
      else if (key === 'supporturl') meta.supportURL = val;
      else if (key === 'homepageurl' || key === 'homepage' || key === 'website') meta.homepageURL = val;
      else if (key === 'author') meta.author = val;
      else if (key === 'license') meta.license = val;
    });
    return { hasMeta: true, header, body, meta };
  }

  function tampermonkeyMatchToHostRule(match) {
    const raw = String(match || '').trim();
    if (!raw) return '';
    const m = raw.match(/^\*:\/\/([^/]+)\//i);
    if (m) return m[1];
    return raw.replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
  }

  function normalizeGrantName(raw) {
    const s = String(raw || '').trim();
    if (!s || s.toLowerCase() === 'none') return '';
    const map = {
      'gm.getvalue': 'GM_getValue',
      'gm.setvalue': 'GM_setValue',
      'gm.deletevalue': 'GM_deleteValue',
      'gm.listvalues': 'GM_listValues',
      'gm.addstyle': 'GM_addStyle',
      'gm.log': 'GM_log',
      'gm.xmlhttprequest': 'GM_xmlhttpRequest',
      'gm.notification': 'GM_notification',
      'gm.registermenucommand': 'GM_registerMenuCommand',
      'gm.unregistermenucommand': 'GM_unregisterMenuCommand',
      'gm.openintab': 'GM_openInTab',
      'gm_openintab': 'GM_openInTab',
      'gm.setclipboard': 'GM_setClipboard',
      'gm_setclipboard': 'GM_setClipboard',
      'gm_getvalue': 'GM_getValue',
      'gm_setvalue': 'GM_setValue',
      'gm_deletevalue': 'GM_deleteValue',
      'gm_listvalues': 'GM_listValues',
      'gm_addstyle': 'GM_addStyle',
      'gm_log': 'GM_log',
      'gm_xmlhttprequest': 'GM_xmlhttpRequest',
      'gm_notification': 'GM_notification',
      'gm_registermenucommand': 'GM_registerMenuCommand',
      'gm_unregistermenucommand': 'GM_unregisterMenuCommand',
    };
    const key = s.replace(/\s+/g, '').toLowerCase();
    return map[key] || s;
  }

  function detectGmApisInCode(code) {
    const src = String(code || '');
    const grants = [];
    const add = (name) => {
      const n = normalizeGrantName(name);
      if (n && grants.indexOf(n) < 0) grants.push(n);
    };
    if (/\bGM_getValue\b/.test(src)) add('GM_getValue');
    if (/\bGM_setValue\b/.test(src)) add('GM_setValue');
    if (/\bGM_deleteValue\b/.test(src)) add('GM_deleteValue');
    if (/\bGM_listValues\b/.test(src)) add('GM_listValues');
    if (/\bGM_addStyle\b/.test(src)) add('GM_addStyle');
    if (/\bGM_log\b/.test(src)) add('GM_log');
    if (/\bGM_xmlhttpRequest\b/.test(src)) add('GM_xmlhttpRequest');
    if (/\bGM_hx0CallTool\b|\bHx0\.callTool\b|\bGM\.hx0\.callTool\b/.test(src)) add('GM_hx0CallTool');
    if (/\bGM_notification\b/.test(src)) add('GM_notification');
    if (/\bGM_registerMenuCommand\b/.test(src)) add('GM_registerMenuCommand');
    if (/\bGM_unregisterMenuCommand\b/.test(src)) add('GM_unregisterMenuCommand');
    if (/\bGM_openInTab\b/.test(src)) add('GM_openInTab');
    if (/\bGM_setClipboard\b/.test(src)) add('GM_setClipboard');
    if (/\bGM\.registerMenuCommand\b/.test(src)) add('GM_registerMenuCommand');
    if (/\bGM\.unregisterMenuCommand\b/.test(src)) add('GM_unregisterMenuCommand');
    if (/\bunsafeWindow\b/.test(src)) add('unsafeWindow');
    if (/\bGM\./.test(src)) {
      add('GM_getValue');
      add('GM_setValue');
      add('GM_addStyle');
      add('GM_log');
      if (/GM\.registerMenuCommand/.test(src)) add('GM_registerMenuCommand');
      if (/GM\.unregisterMenuCommand/.test(src)) add('GM_unregisterMenuCommand');
    }
    return grants;
  }

  function scriptUsesMenuCommands(code) {
    const src = String(code || '');
    if (!src) return false;
    if (detectGmApisInCode(src).indexOf('GM_registerMenuCommand') >= 0) return true;
    const parsed = parseTampermonkeyHeader(src);
    if (!parsed.hasMeta || !parsed.meta) return false;
    return (parsed.meta.grants || []).some((grant) => normalizeGrantName(grant) === 'GM_registerMenuCommand');
  }

  function resolveGrants(meta, body) {
    const declared = meta && Array.isArray(meta.grants) ? meta.grants.slice() : [];
    const detected = detectGmApisInCode(body);
    const merged = {};
    declared.forEach((g) => {
      const n = normalizeGrantName(g);
      if (n) merged[n] = true;
    });
    if (!declared.length || (declared.length === 1 && normalizeGrantName(declared[0]) === '')) {
      detected.forEach((g) => { merged[g] = true; });
    } else {
      detected.forEach((g) => { merged[g] = true; });
    }
    return Object.keys(merged);
  }

  function buildGmBootstrap(scriptId, grants) {
    const list = Array.isArray(grants) ? grants : [];
    const set = {};
    list.forEach((g) => { set[String(g || '').trim()] = true; });
    const sid = JSON.stringify(String(scriptId || 'default'));
    const lines = [';(function(){'];
    lines.push('var g=typeof globalThis!=="undefined"?globalThis:window;');
    lines.push('var __hx0_sid=' + sid + ';');
    lines.push('var __hx0_gp=function(k){return"hx0_gm_"+__hx0_sid+"_"+String(k||"");};');
    lines.push('var __hx0_ep=function(){return"__hx0_gm_last_error__"+__hx0_sid;};');
    lines.push('var __hx0_err_suppressible=function(err){if(!err)return true;var w=String(err.where||""),m=String(err.message||""),b=w+"\\n"+m;if(/^@require:/i.test(w)&&/jquery/i.test(b))return true;if(/^@require:/i.test(w)&&/example\\.(com|org|net)/i.test(b))return true;if(/unsafe-eval/i.test(m)&&/jquery|@require/i.test(b))return true;if(/Content Security Policy|unsafe-eval|Sink type mismatch|Trusted Types|blocked by CSP/i.test(m))return true;return false;};');
    lines.push('var __hx0_record_error=function(where,e){try{var whereText=String(where||"脚本运行");var msg=String((e&&e.stack)||(e&&e.message)||e||"unknown error");if(/^@require:/i.test(whereText)&&/jquery|example\\.(com|org|net)/i.test(whereText+msg))return;if(/unsafe-eval/i.test(msg)&&/jquery|@require/i.test(whereText+msg))return;localStorage.setItem(__hx0_ep(),JSON.stringify({where:whereText,message:msg,at:Date.now()}));}catch(_e){}};');
    lines.push('try{g.__hx0RecordUserScriptError__=__hx0_record_error;}catch(_e){}');
    lines.push('var __hx0_attach=function(name,fn){try{g[name]=fn;}catch(e){try{window[name]=fn;}catch(e2){}}}');
    lines.push('function __hx0_call_tool(tool,input,options){return new Promise(function(resolve,reject){var PREFIX="Hx0HawkEye";var opts=options&&typeof options==="object"?options:{};var reqId="tool_"+Date.now()+"_"+Math.random().toString(36).slice(2,8);var timeout=Number(opts.timeout||120000);if(!isFinite(timeout)||timeout<1000)timeout=120000;function done(ok,val){try{window.removeEventListener("message",onmsg);}catch(_e){}clearTimeout(timer);ok?resolve(val):reject(val);}function onmsg(ev){var d=ev.data;if(!d||d.source!==PREFIX||d.type!=="HX0_TOOL_RESULT"||d.requestId!==reqId)return;var res=d.result||{ok:false,error:"empty"};if(!res.ok)done(false,res);else done(true,res.result!==undefined?res.result:res);}try{window.addEventListener("message",onmsg);window.postMessage({source:PREFIX,type:"HX0_TOOL_CALL",requestId:reqId,tool:String(tool||""),input:input&&typeof input==="object"?input:{},traceId:String(opts.traceId||""),scriptId:__hx0_sid,sourceName:"user-script"},"*");}catch(e){done(false,{ok:false,error:String((e&&e.message)||e)});return;}var timer=setTimeout(function(){done(false,{ok:false,error:"Hx0.callTool timeout"});},timeout);});}');
    lines.push('g.Hx0=g.Hx0||{};g.Hx0.callTool=__hx0_call_tool;__hx0_attach("GM_hx0CallTool",__hx0_call_tool);');
    if (set.GM_getValue || set.GM_setValue || set.GM_deleteValue || set.GM_listValues) {
      lines.push('__hx0_attach("GM_getValue",function(k,d){try{var v=localStorage.getItem(__hx0_gp(k));return v==null?d:JSON.parse(v);}catch(e){return d;}});');
      lines.push('__hx0_attach("GM_setValue",function(k,v){localStorage.setItem(__hx0_gp(k),JSON.stringify(v));});');
      lines.push('__hx0_attach("GM_deleteValue",function(k){localStorage.removeItem(__hx0_gp(k));});');
      lines.push('__hx0_attach("GM_listValues",function(){var p=__hx0_gp("");return Object.keys(localStorage).filter(function(x){return x.indexOf(p)===0;}).map(function(x){return x.slice(p.length);});});');
    }
    if (set.GM_addStyle) {
      lines.push('__hx0_attach("GM_addStyle",function(css){var el=document.createElement("style");el.textContent=String(css||"");(document.head||document.documentElement).appendChild(el);return el;});');
    }
    if (set.GM_setClipboard) {
      lines.push('__hx0_attach("GM_setClipboard",function(data,info){');
      lines.push('var text=String(data==null?"":data);');
      lines.push('var o=info&&typeof info==="object"?info:{};');
      lines.push('var ondone=typeof o.ondone==="function"?o.ondone:null;');
      lines.push('var onerror=typeof o.onerror==="function"?o.onerror:null;');
      lines.push('function finish(err){if(err){if(onerror)try{onerror(err);}catch(e){}else if(ondone)try{ondone(err);}catch(e2){}}else if(ondone)try{ondone(null);}catch(e3){}}');
      lines.push('function legacy(){try{var ta=document.createElement("textarea");ta.value=text;ta.setAttribute("readonly","");ta.style.cssText="position:fixed;left:-9999px;top:0;opacity:0;";(document.documentElement||document.body).appendChild(ta);ta.focus();ta.select();var ok=document.execCommand("copy");if(ta.parentNode)ta.parentNode.removeChild(ta);finish(ok?null:new Error("copy failed"));}catch(e){finish(e);}}');
      lines.push('if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(text).then(function(){finish(null);}).catch(legacy);return;}');
      lines.push('legacy();');
      lines.push('});');
    }
    if (set.GM_log) {
      lines.push('__hx0_attach("GM_log",function(){try{console.log.apply(console,arguments);}catch(e){}});');
    }
    if (set.GM_notification) {
      lines.push('__hx0_attach("GM_notification",function(o){try{var t=String((o&&o.text)||"");if(t&&typeof alert==="function")alert(t);}catch(e){}});');
    }
    if (set.GM_openInTab) {
      lines.push('__hx0_attach("GM_openInTab",function(url,opts){var u=String(url||"");var o=opts&&typeof opts==="object"?opts:{};var w=window.open(u,"_blank");if(o.active!==false&&w){try{w.focus();}catch(e){}}return {close:function(){try{w&&w.close();}catch(e){}},closed:false,onload:null};});');
    }
    if (set.GM_xmlhttpRequest) {
      lines.push('__hx0_attach("GM_xmlhttpRequest",function(x){');
      lines.push('x=x||{};var PREFIX="Hx0HawkEye";');
      lines.push('function __hx0_xhr_finish(res,err){');
      lines.push('if(err){if(typeof x.onerror==="function")try{x.onerror(err);}catch(e){}if(typeof x.onloadend==="function")try{x.onloadend({});}catch(e2){}return;}');
      lines.push('var rt=String(x.responseType||"").toLowerCase();');
      lines.push('var response=res.responseText||"";');
      lines.push('if(rt==="json"){try{response=res.parsed!=null?res.parsed:JSON.parse(res.responseText||"null");}catch(e){response=null;}}');
      lines.push('else if((rt==="blob"||rt==="arraybuffer")&&res.responseBase64){var bin=atob(res.responseBase64),arr=new Uint8Array(bin.length);for(var i=0;i<bin.length;i++)arr[i]=bin.charCodeAt(i);response=rt==="arraybuffer"?arr.buffer:new Blob([arr]);}');
      lines.push('var detail={status:res.status||0,statusText:res.statusText||"",responseText:res.responseText||"",response:response,responseHeaders:res.responseHeaders||"",finalUrl:res.finalUrl||String(x.url||"")};');
      lines.push('if(typeof x.onload==="function")try{x.onload(detail);}catch(e3){}');
      lines.push('if(typeof x.onreadystatechange==="function")try{x.onreadystatechange(detail);}catch(e4){}');
      lines.push('if(typeof x.onloadend==="function")try{x.onloadend(detail);}catch(e5){}');
      lines.push('}');
      lines.push('function __hx0_xhr_fetch(){');
      lines.push('var rt=String(x.responseType||"").toLowerCase();');
      lines.push('fetch(String(x.url||""),{method:String(x.method||"GET").toUpperCase(),headers:x.headers||{},body:x.data,credentials:x.withCredentials===false?"omit":"include"})');
      lines.push('.then(function(r){var hs="";try{r.headers.forEach(function(v,k){hs+=k+": "+v+"\\r\\n";});}catch(e){}');
      lines.push('if(rt==="blob")return r.blob().then(function(b){__hx0_xhr_finish({status:r.status,statusText:r.statusText,responseText:"",parsed:b,responseBase64:"",responseHeaders:hs,finalUrl:r.url});});');
      lines.push('if(rt==="arraybuffer")return r.arrayBuffer().then(function(ab){var u8=new Uint8Array(ab),s="";for(var i=0;i<u8.length;i++)s+=String.fromCharCode(u8[i]);__hx0_xhr_finish({status:r.status,statusText:r.statusText,responseText:"",parsed:ab,responseBase64:btoa(s),responseHeaders:hs,finalUrl:r.url});});');
      lines.push('if(rt==="json")return r.text().then(function(t){var p=null;try{p=JSON.parse(t);}catch(e){}__hx0_xhr_finish({status:r.status,statusText:r.statusText,responseText:t,parsed:p,responseHeaders:hs,finalUrl:r.url});});');
      lines.push('return r.text().then(function(t){__hx0_xhr_finish({status:r.status,statusText:r.statusText,responseText:t,parsed:t,responseHeaders:hs,finalUrl:r.url});});');
      lines.push('}).catch(function(e){__hx0_xhr_finish(null,e);});');
      lines.push('}');
      lines.push('var reqId="xhr_"+Date.now()+"_"+Math.random().toString(36).slice(2,8),done=false;');
      lines.push('function __hx0_xhr_onmsg(ev){var d=ev.data;if(!d||d.source!==PREFIX||d.type!=="USER_SCRIPT_GM_XHR_RESPONSE"||d.requestId!==reqId)return;');
      lines.push('done=true;window.removeEventListener("message",__hx0_xhr_onmsg);clearTimeout(__hx0_xhr_timer);');
      lines.push('var res=d.result||{ok:false,error:"empty"};if(!res.ok){__hx0_xhr_finish(null,res.error||"xhr failed");return;}__hx0_xhr_finish(res);}');
      lines.push('window.addEventListener("message",__hx0_xhr_onmsg);');
      lines.push('try{window.postMessage({source:PREFIX,type:"USER_SCRIPT_GM_XHR",requestId:reqId,details:{url:String(x.url||""),method:String(x.method||"GET"),headers:x.headers||{},data:x.data,responseType:String(x.responseType||""),withCredentials:x.withCredentials!==false}},"*");}catch(e6){done=true;window.removeEventListener("message",__hx0_xhr_onmsg);__hx0_xhr_fetch();return;}');
      lines.push('var __hx0_xhr_timeout=Number(x.timeout||30000);if(!isFinite(__hx0_xhr_timeout)||__hx0_xhr_timeout<1000)__hx0_xhr_timeout=30000;');
      lines.push('var __hx0_xhr_timer=setTimeout(function(){if(done)return;done=true;window.removeEventListener("message",__hx0_xhr_onmsg);__hx0_xhr_fetch();},__hx0_xhr_timeout);');
      lines.push('});');
    }
    if (set.unsafeWindow) {
      lines.push('__hx0_attach("unsafeWindow",window);');
    }
    if (set.GM_registerMenuCommand || set.GM_unregisterMenuCommand) {
      lines.push('g.__hx0GmMenus__=g.__hx0GmMenus__||{};');
      lines.push('function __hx0_sync_menu_meta(){');
      lines.push('try{var sid=__hx0_sid;var list=(g.__hx0GmMenus__&&g.__hx0GmMenus__[sid])||[];');
      lines.push('var meta=list.map(function(x){return {id:x.id,title:x.title,accessKey:x.accessKey||""};});');
      lines.push('localStorage.setItem("__hx0_gm_menu_meta__"+sid,JSON.stringify(meta));');
      lines.push('if(typeof unsafeWindow!=="undefined"&&unsafeWindow){unsafeWindow.__hx0GmMenus__=g.__hx0GmMenus__;}');
      lines.push('}catch(e){}};');
      lines.push('__hx0_attach("GM_registerMenuCommand",function(name,fn,accessKey){');
      lines.push('var sid=__hx0_sid;');
      lines.push('if(!g.__hx0GmMenus__[sid])g.__hx0GmMenus__[sid]=[];');
      lines.push('var id="m_"+Date.now()+"_"+Math.random().toString(36).slice(2,8);');
      lines.push('var title=String(name||"");');
      lines.push('var wrapped=function(){try{var ret=typeof fn==="function"?fn.apply(this,arguments):undefined;if(ret&&typeof ret.then==="function")ret.catch(function(e){__hx0_record_error("菜单："+title,e);});return ret;}catch(e){__hx0_record_error("菜单："+title,e);throw e;}};');
      lines.push('var entry={id:id,title:title,accessKey:accessKey?String(accessKey):"",callback:wrapped};');
      lines.push('var idx=g.__hx0GmMenus__[sid].findIndex(function(x){return x.title===title;});');
      lines.push('if(idx>=0)g.__hx0GmMenus__[sid][idx]=entry;else g.__hx0GmMenus__[sid].push(entry);');
      lines.push('__hx0_sync_menu_meta();');
      lines.push('return id;');
      lines.push('});');
      lines.push('__hx0_attach("GM_unregisterMenuCommand",function(id){');
      lines.push('var sid=__hx0_sid;');
      lines.push('var list=g.__hx0GmMenus__&&g.__hx0GmMenus__[sid];');
      lines.push('if(!list)return;');
      lines.push('var idx=list.findIndex(function(x){return x.id===id;});');
      lines.push('if(idx>=0)list.splice(idx,1);');
      lines.push('__hx0_sync_menu_meta();');
      lines.push('});');
    }
    lines.push('g.GM=g.GM||{};');
    lines.push('if(typeof g.GM_getValue==="function")g.GM.getValue=g.GM_getValue;');
    lines.push('if(typeof g.GM_setValue==="function")g.GM.setValue=g.GM_setValue;');
    lines.push('if(typeof g.GM_deleteValue==="function")g.GM.deleteValue=g.GM_deleteValue;');
    lines.push('if(typeof g.GM_listValues==="function")g.GM.listValues=g.GM_listValues;');
    lines.push('if(typeof g.GM_addStyle==="function")g.GM.addStyle=g.GM_addStyle;');
    lines.push('if(typeof g.GM_log==="function")g.GM.log=g.GM_log;');
    lines.push('if(typeof g.GM_xmlhttpRequest==="function")g.GM.xmlhttpRequest=g.GM_xmlhttpRequest;');
    lines.push('if(typeof g.GM_hx0CallTool==="function"){g.GM.hx0=g.GM.hx0||{};g.GM.hx0.callTool=g.GM_hx0CallTool;}');
    lines.push('if(typeof g.GM_openInTab==="function")g.GM.openInTab=g.GM_openInTab;');
    lines.push('if(typeof g.GM_setClipboard==="function")g.GM.setClipboard=g.GM_setClipboard;');
    lines.push('if(typeof g.GM_registerMenuCommand==="function")g.GM.registerMenuCommand=g.GM_registerMenuCommand;');
    lines.push('if(typeof g.GM_unregisterMenuCommand==="function")g.GM.unregisterMenuCommand=g.GM_unregisterMenuCommand;');
    lines.push('})();');
    return lines.join('\n');
  }

  const HX0_BUNDLED_JQUERY = 'src/shared/jquery-3.7.1.min.js';

  function isPlaceholderRequireError(err) {
    if (!err || typeof err !== 'object') return false;
    const where = String(err.where || '');
    if (!/^@require:/i.test(where)) return false;
    const url = where.replace(/^@require:\s*/i, '').trim();
    return isPlaceholderRequireUrl(url);
  }

  function isSuppressibleUserScriptError(err) {
    if (!err || typeof err !== 'object') return false;
    const where = String(err.where || '');
    const message = String(err.message || '');
    const blob = where + '\n' + message;
    if (isPlaceholderRequireError(err)) return true;
    if (/^@require:/i.test(where) && /jquery/i.test(blob)) return true;
    if (/unsafe-eval/i.test(message) && /jquery|@require/i.test(blob)) return true;
    if (/Content Security Policy|unsafe-eval|Sink type mismatch|Trusted Types|blocked by CSP/i.test(message)) return true;
    return false;
  }

  function sanitizeUserScriptLastError(lastError) {
    if (!lastError) return null;
    return isSuppressibleUserScriptError(lastError) ? null : lastError;
  }

  function buildReadLastErrorProbeCode() {
    return 'function __hx0_err_suppressible(err){if(!err)return true;var w=String(err.where||""),m=String(err.message||""),b=w+"\\n"+m;if(/^@require:/i.test(w)&&/jquery/i.test(b))return true;if(/^@require:/i.test(w)&&/example\\.(com|org|net)/i.test(b))return true;if(/unsafe-eval/i.test(m)&&/jquery|@require/i.test(b))return true;if(/Content Security Policy|unsafe-eval|Sink type mismatch|Trusted Types|blocked by CSP/i.test(m))return true;return false;}'
      + 'function readLastError(){try{var k="__hx0_gm_last_error__"+sid;var raw=localStorage.getItem(k);if(!raw)return null;var err=JSON.parse(raw);if(__hx0_err_suppressible(err)){try{localStorage.removeItem(k);}catch(e){}return null;}return err;}catch(e){return null;}}';
  }

  function stripTampermonkeyPlaceholderMeta(code) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    const header = parsed.header.split(/\r?\n/).filter((line) => {
      const row = line.match(/^\s*\/\/\s*@([\w-]+)\s+(.*)$/);
      if (!row) return true;
      const key = String(row[1] || '').toLowerCase();
      const val = String(row[2] || '').trim();
      if (key === 'require' && isPlaceholderRequireUrl(val)) return false;
      if (key === 'resource' && /example\.(com|org|net)/i.test(val)) return false;
      if (key === 'connect' && /^example\.(com|org|net)$/i.test(val)) return false;
      return true;
    }).join('\n');
    return header + parsed.body;
  }

  function isJqueryRequireUrl(url) {
    return /jquery/i.test(String(url || ''));
  }

  function isPlaceholderRequireUrl(url) {
    const u = String(url || '').trim().toLowerCase();
    if (!u) return true;
    if (/^https?:\/\/(?:www\.)?example\.(?:com|org|net)\//i.test(u)) return true;
    if (/^https?:\/\/(?:www\.)?example\.(?:com|org|net)$/i.test(u)) return true;
    return false;
  }

  function partitionRequires(requires) {
    const jquery = [];
    const other = [];
    (Array.isArray(requires) ? requires : []).forEach((u) => {
      const s = String(u || '').trim();
      if (!s || !/^https?:\/\//i.test(s)) return;
      if (isPlaceholderRequireUrl(s)) return;
      if (isJqueryRequireUrl(s)) jquery.push(s);
      else other.push(s);
    });
    return { jquery, other };
  }

  function buildJqueryCdnLoaderCode(jqueryUrls) {
    const encoded = JSON.stringify(Array.isArray(jqueryUrls) ? jqueryUrls : []);
    return 'globalThis.__hx0_jq_cdn_promise=(async function __hx0_jq_cdn_load(){\n'
      + 'if(globalThis.jQuery&&globalThis.$)return;\n'
      + 'var __hx0_jq_urls=' + encoded + ';\n'
      + 'function __hx0_jq_candidates(__hx0_u){var out=[__hx0_u];try{var s=String(__hx0_u||"");if(/^http:\\/\\//i.test(s))out.push("https://"+s.slice(7));if(/jquery/i.test(s)){var m=s.match(/jquery[-\\/]([0-9]+(?:\\.[0-9]+){1,2})(?:\\.min)?\\.js/i);var v=m&&m[1]?m[1]:"2.0.0";out.push("https://code.jquery.com/jquery-"+v+".min.js");out.push("https://ajax.aspnetcdn.com/ajax/jquery/jquery-"+v+".min.js");}}catch(e){}return out.filter(function(x,i,a){return x&&a.indexOf(x)===i;});}\n'
      + 'function __hx0_jq_fetch(__hx0_u){return new Promise(function(resolve,reject){if(typeof GM_xmlhttpRequest==="function"){try{GM_xmlhttpRequest({url:__hx0_u,method:"GET",responseType:"text",timeout:30000,onload:function(r){resolve(String((r&&r.responseText)||(r&&r.response)||""));},onerror:function(){reject();},ontimeout:function(){reject();}});return;}catch(e){}}fetch(__hx0_u,{credentials:"omit"}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.text();}).then(resolve).catch(reject);});}\n'
      + 'for(var __hx0_i=0;__hx0_i<__hx0_jq_urls.length;__hx0_i++){\n'
      + 'var __hx0_lists=__hx0_jq_candidates(__hx0_jq_urls[__hx0_i]);\n'
      + 'for(var __hx0_k=0;__hx0_k<__hx0_lists.length;__hx0_k++){\n'
      + 'try{var __hx0_jc=await __hx0_jq_fetch(__hx0_lists[__hx0_k]);if(__hx0_jc){(0,eval)(__hx0_jc);}}catch(__hx0_ign){}\n'
      + 'if(globalThis.jQuery&&globalThis.$)return;\n'
      + '}}\n'
      + '})();\n';
  }

  function buildJqueryEntryPreamble() {
    return 'try{await(globalThis.__hx0_jq_cdn_promise||Promise.resolve());}catch(_hx0_jqe){}\n'
      + 'if(typeof globalThis.jQuery==="function"&&typeof globalThis.$==="undefined"){try{globalThis.$=globalThis.jQuery;}catch(_e){}}\n'
      + 'try{if(typeof __hx0_ep==="function")localStorage.removeItem(__hx0_ep());}catch(_e){}\n';
  }

  function wrapUserScriptBodyWithRequires(body, requires, options) {
    const opts = options && typeof options === 'object' ? options : {};
    const preamble = String(opts.preamble || '');
    const urls = (Array.isArray(requires) ? requires : [])
      .map((u) => String(u || '').trim())
      .filter((u) => /^https?:\/\//i.test(u) && !isJqueryRequireUrl(u) && !isPlaceholderRequireUrl(u));
    if (!urls.length && !preamble) return String(body || '');
    const encoded = JSON.stringify(urls);
    if (!urls.length) {
      return '(async function __hx0_user_script_entry(){\n'
        + preamble
        + 'try{\n'
        + String(body || '')
        + '\n}catch(__hx0_body_err){try{globalThis.__hx0RecordUserScriptError__&&globalThis.__hx0RecordUserScriptError__("脚本初始化",__hx0_body_err);}catch(__hx0_e3){}console.error("[Hx0] user script failed",__hx0_body_err);}\n'
        + '})();';
    }
    return '(async function __hx0_user_script_entry(){\n'
      + preamble
      + 'var __hx0_req=' + encoded + ';\n'
      + 'function __hx0_require_candidates(__hx0_u){var out=[__hx0_u];try{var s=String(__hx0_u||"");if(/^http:\\/\\//i.test(s))out.push("https://"+s.slice(7));}catch(e){}return out.filter(function(x,i,a){return x&&a.indexOf(x)===i;});}\n'
      + 'function __hx0_load_require(__hx0_u){return new Promise(function(resolve,reject){\n'
      + 'if(typeof GM_xmlhttpRequest==="function"){try{GM_xmlhttpRequest({url:__hx0_u,method:"GET",responseType:"text",timeout:30000,onload:function(r){resolve(String((r&&r.responseText)||(r&&r.response)||""));},onerror:function(e){reject(e||new Error("GM_xmlhttpRequest failed"));},ontimeout:function(){reject(new Error("GM_xmlhttpRequest timeout"));}});return;}catch(__hx0_gm_err){}}\n'
      + 'fetch(__hx0_u,{credentials:"omit"}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.text();}).then(resolve).catch(reject);\n'
      + '});}\n'
      + 'async function __hx0_load_require_any(__hx0_u){var list=__hx0_require_candidates(__hx0_u),last=null;for(var k=0;k<list.length;k++){try{return await __hx0_load_require(list[k]);}catch(e){last=e;}}throw last||new Error("require failed");}\n'
      + 'for(var __hx0_i=0;__hx0_i<__hx0_req.length;__hx0_i++){\n'
      + 'var __hx0_u=__hx0_req[__hx0_i];\n'
      + 'try{\n'
      + 'var __hx0_code=await __hx0_load_require_any(__hx0_u);\n'
      + 'if(__hx0_code){(0,eval)(__hx0_code);}\n'
      + '}catch(__hx0_err){console.warn("[Hx0] @require skipped",__hx0_u,String((__hx0_err&&__hx0_err.message)||__hx0_err||""));}\n'
      + '}\n'
      + 'try{\n'
      + String(body || '')
      + '\n}catch(__hx0_body_err){try{globalThis.__hx0RecordUserScriptError__&&globalThis.__hx0RecordUserScriptError__("脚本初始化",__hx0_body_err);}catch(__hx0_e3){}console.error("[Hx0] user script failed",__hx0_body_err);}\n'
      + '})();';
  }

  function prepareUserScriptRegistration(script) {
    const item = script && typeof script === 'object' ? script : { code: script, id: 'default' };
    const parsed = parseTampermonkeyHeader(item.code);
    const requires = parsed.meta && parsed.meta.requires ? parsed.meta.requires : [];
    const parts = partitionRequires(requires);
    const grants = resolveGrants(parsed.meta, parsed.body);
    if (requires.length && grants.indexOf('GM_xmlhttpRequest') < 0) {
      grants.push('GM_xmlhttpRequest');
    }
    const bootstrap = buildGmBootstrap(item.id, grants);
    const body = wrapUserScriptBodyWithRequires(parsed.body, parts.other);

    if (!parts.jquery.length) {
      const code = bootstrap ? (bootstrap + '\n' + body) : body;
      return { hasJquery: false, js: [{ code }] };
    }

    const cdnLoader = buildJqueryCdnLoaderCode(parts.jquery);
    const clearStaleError = 'try{if(typeof __hx0_ep==="function")localStorage.removeItem(__hx0_ep());}catch(_hx0_clr){}\n';
    const entryBody = wrapUserScriptBodyWithRequires(parsed.body, parts.other, {
      preamble: buildJqueryEntryPreamble(),
    });
    return {
      hasJquery: true,
      js: [
        { code: (bootstrap ? bootstrap + '\n' : '') + clearStaleError + cdnLoader },
        { file: HX0_BUNDLED_JQUERY },
        { code: entryBody },
      ],
    };
  }

  function extractTampermonkeyMatchRules(meta) {
    const out = [];
    (meta && Array.isArray(meta.matches) ? meta.matches : []).forEach((rule) => {
      const val = String(rule || '').trim();
      if (val && out.indexOf(val) < 0) out.push(val);
    });
    (meta && Array.isArray(meta.includes) ? meta.includes : []).forEach((rule) => {
      const val = String(rule || '').trim();
      if (val && out.indexOf(val) < 0) out.push(val);
    });
    return out;
  }

  function normalizeTampermonkeyDomainRuleEntry(entry, defaultType) {
    if (entry && typeof entry === 'object') {
      const type = String(entry.type || defaultType || 'match').replace(/^@/, '').toLowerCase();
      const value = String(entry.value || entry.rule || '').trim();
      if (!value) return null;
      if (['match', 'include', 'exclude', 'connect'].indexOf(type) < 0) return null;
      return { type, value };
    }
    let raw = String(entry || '').trim();
    if (!raw) return null;
    const prefixed = raw.match(/^@?(match|include|exclude|connect)\s+(.+)$/i);
    if (prefixed) {
      raw = String(prefixed[2] || '').trim();
      if (!raw) return null;
      return { type: String(prefixed[1] || '').toLowerCase(), value: raw };
    }
    return { type: String(defaultType || 'match').replace(/^@/, '').toLowerCase(), value: raw };
  }

  function dedupeTampermonkeyDomainRules(rules) {
    const out = [];
    const seen = {};
    (Array.isArray(rules) ? rules : []).forEach((rule) => {
      const item = normalizeTampermonkeyDomainRuleEntry(rule);
      if (!item) return;
      const key = item.type + '\n' + item.value;
      if (seen[key]) return;
      seen[key] = true;
      out.push(item);
    });
    return out;
  }

  function extractTampermonkeyDomainRules(meta) {
    const rules = [];
    (meta && Array.isArray(meta.matches) ? meta.matches : []).forEach((value) => rules.push({ type: 'match', value }));
    (meta && Array.isArray(meta.includes) ? meta.includes : []).forEach((value) => rules.push({ type: 'include', value }));
    (meta && Array.isArray(meta.excludes) ? meta.excludes : []).forEach((value) => rules.push({ type: 'exclude', value }));
    (meta && Array.isArray(meta.connects) ? meta.connects : []).forEach((value) => rules.push({ type: 'connect', value }));
    return dedupeTampermonkeyDomainRules(rules);
  }

  function parseTampermonkeyDomainRulesInput(input, defaultType) {
    if (Array.isArray(input)) return dedupeTampermonkeyDomainRules(input);
    const out = [];
    String(input || '').split(/\r?\n/).forEach((line) => {
      const raw = String(line || '').trim();
      if (!raw) return;
      if (/^@?(match|include|exclude|connect)\s+/i.test(raw)) {
        const item = normalizeTampermonkeyDomainRuleEntry(raw, defaultType || 'match');
        if (item) out.push(item);
        return;
      }
      raw.split(/[,，]+/).forEach((part) => {
        const item = normalizeTampermonkeyDomainRuleEntry(part, defaultType || 'match');
        if (item) out.push(item);
      });
    });
    return dedupeTampermonkeyDomainRules(out);
  }

  function formatTampermonkeyDomainRulesForEditor(rules) {
    return dedupeTampermonkeyDomainRules(rules).map((rule) => {
      if (rule.type === 'match') return rule.value;
      return '@' + rule.type + ' ' + rule.value;
    }).join('\n');
  }

  function inferTampermonkeyMatchModeFromRules(rules) {
    const list = Array.isArray(rules)
      ? dedupeTampermonkeyDomainRules(rules)
      : parseTampermonkeyDomainRulesInput(rules, 'match');
    const matchRules = list.filter((rule) => rule.type === 'match' || rule.type === 'include');
    if (matchRules.some((rule) => String(rule.value || '').trim() === '*://*/*')) return 'all';
    if (matchRules.length) return 'matches';
    return 'manual';
  }

  function buildTampermonkeyDomainRulesForMatchMode(matchMode, currentRules) {
    const parsed = Array.isArray(currentRules)
      ? dedupeTampermonkeyDomainRules(currentRules)
      : parseTampermonkeyDomainRulesInput(currentRules, 'match');
    const nonMatchRules = parsed.filter((rule) => rule.type !== 'match' && rule.type !== 'include');
    const existingMatchRules = parsed.filter((rule) => rule.type === 'match' || rule.type === 'include');
    const mode = ['manual', 'matches', 'all'].indexOf(String(matchMode || '')) >= 0 ? String(matchMode) : 'manual';
    // 手动执行不依赖 @match/@connect；Hx0 GM 请求走扩展桥接，无需保留 @connect
    if (mode === 'manual') return [];
    if (mode === 'all') {
      const wildcard = { type: 'match', value: '*://*/*' };
      const kept = existingMatchRules.filter((rule) => String(rule.value || '').trim() === '*://*/*');
      return dedupeTampermonkeyDomainRules((kept.length ? kept : [wildcard]).concat(nonMatchRules));
    }
    const specific = existingMatchRules.filter((rule) => String(rule.value || '').trim() !== '*://*/*');
    return dedupeTampermonkeyDomainRules(specific.concat(nonMatchRules));
  }

  function appendTampermonkeyHostToDomainRules(currentRules, host) {
    const hostStr = String(host || '').trim();
    if (!hostStr) {
      return Array.isArray(currentRules)
        ? dedupeTampermonkeyDomainRules(currentRules)
        : parseTampermonkeyDomainRulesInput(currentRules, 'match');
    }
    const parsed = Array.isArray(currentRules)
      ? dedupeTampermonkeyDomainRules(currentRules)
      : parseTampermonkeyDomainRulesInput(currentRules, 'match');
    const nonMatchRules = parsed.filter((rule) => rule.type !== 'match' && rule.type !== 'include');
    let matchRules = parsed
      .filter((rule) => rule.type === 'match' || rule.type === 'include')
      .filter((rule) => String(rule.value || '').trim() !== '*://*/*');
    const patterns = hostRuleToTampermonkeyMatchPatterns(hostStr);
    const hostLower = hostStr.toLowerCase();
    patterns.forEach((pattern) => {
      const alreadyHas = matchRules.some((rule) => {
        const val = String(rule.value || '').trim();
        return val === pattern || tampermonkeyMatchToHostRule(val).toLowerCase() === hostLower;
      });
      if (!alreadyHas) matchRules.unshift({ type: 'match', value: pattern });
    });
    // 不写入 @connect：Hx0 的 GM_xmlhttpRequest 由扩展 background 代发（<all_urls>），无需油猴式 @connect
    return dedupeTampermonkeyDomainRules(matchRules.concat(nonMatchRules));
  }

  function extractTampermonkeyMatchConfig(code) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed || !parsed.hasMeta || !parsed.meta) {
      return { matchMode: 'manual', matches: [], domainRules: [], runAt: '', hasMeta: false };
    }
    const rules = extractTampermonkeyMatchRules(parsed.meta);
    const domainRules = extractTampermonkeyDomainRules(parsed.meta);
    return {
      hasMeta: true,
      matchMode: rules.length ? 'matches' : 'manual',
      matches: rules,
      domainRules,
      domainRulesText: formatTampermonkeyDomainRulesForEditor(domainRules),
      runAt: parsed.meta.runAt || '',
      name: parsed.meta.name || '',
    };
  }

  function detectPreferredUserScriptWorld(body) {
    const src = String(body || '');
    if (/\bHTMLMediaElement\.prototype\b/.test(src)) return 'MAIN';
    if (/\bunsafeWindow\b/.test(src)) return 'MAIN';
    return '';
  }

  function applyTampermonkeyMetaToScript(script, parsed, options) {
    const base = script && typeof script === 'object' ? Object.assign({}, script) : {};
    if (!parsed || !parsed.hasMeta || !parsed.meta) return base;
    const meta = parsed.meta;
    if (meta.name) base.name = meta.name;
    const rules = extractTampermonkeyMatchRules(meta);
    if (rules.length) {
      base.matchMode = 'matches';
      base.matches = rules;
    }
    if (meta.runAt) base.runAt = meta.runAt;
    const preferredWorld = detectPreferredUserScriptWorld(parsed.body);
    const opts = options && typeof options === 'object' ? options : {};
    // 导入新脚本时可按代码特征推荐 MAIN；编辑器保存时 preserveWorld 保留用户所选注入世界
    if (preferredWorld && !opts.preserveWorld) {
      base.world = preferredWorld;
    }
    if (meta.description) base.description = meta.description;
    if (meta.noframes) base.allFrames = false;
    base.tampermonkey = {
      grants: meta.grants || [],
      connects: meta.connects || [],
      resources: meta.resources || [],
      noframes: !!meta.noframes,
      namespace: meta.namespace || '',
      version: meta.version || '',
      downloadURL: meta.downloadURL || '',
      updateURL: meta.updateURL || '',
      supportURL: meta.supportURL || '',
      homepageURL: meta.homepageURL || '',
      author: meta.author || '',
      license: meta.license || '',
      hasMeta: true,
    };
    return base;
  }

  function prepareUserScriptExecutionCode(script) {
    const reg = prepareUserScriptRegistration(script);
    return reg.js.map((entry) => String(entry.code || '')).filter(Boolean).join('\n');
  }

  const DEFAULT_USER_SCRIPT_CODE = [
    '// ==UserScript==',
    '// @name         新脚本',
    '// @namespace    http://hx0.local/',
    '// @version      1.0.0',
    '// @description  在此填写脚本描述',
    '// @author       ',
    '// @license      MIT',
    '// @match        *://*/*',
    '// @grant        GM_getResourceText',
    '// @grant        GM_info',
    '// @grant        unsafeWindow',
    '// @grant        GM_xmlhttpRequest',
    '// @grant        GM_hx0CallTool',
    '// @grant        GM_addStyle',
    '// @grant        GM_registerMenuCommand',
    '// @grant        GM_setValue',
    '// @grant        GM_getValue',
    '// @grant        GM_deleteValue',
    '// @grant        GM_setClipboard',
    '// @grant        GM_cookie',
    '// @run-at       document-end',
    '// ==/UserScript==',
    '',
    '(function () {',
    "  'use strict';",
    "  console.log('[Hx0] user script ready:', location.href);",
    '})();',
  ].join('\n');

  function getDefaultUserScriptCode() {
    return DEFAULT_USER_SCRIPT_CODE;
  }

  function updateTampermonkeyMetaName(code, name) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    const val = String(name || '').trim();
    const header = parsed.header;
    const nameLineRe = /^\s*\/\/\s*@name\s+.*/m;
    const newNameLine = '// @name         ' + val;
    let newHeader;
    if (nameLineRe.test(header)) {
      newHeader = header.replace(nameLineRe, newNameLine);
    } else {
      newHeader = header.replace(/(^\s*\/\/\s*==UserScript==\s*\r?\n)/m, '$1' + newNameLine + '\n');
    }
    return newHeader + parsed.body;
  }

  function hostRuleToTampermonkeyMatchPatterns(rule) {
    const raw = String(rule || '').trim();
    if (!raw || raw === '*') return ['*://*/*'];
    if (/^\*:\/\//.test(raw)) return [raw];
    if (/^https?:\/\//i.test(raw)) {
      try {
        const u = new URL(raw);
        return ['*://' + u.host + '/*'];
      } catch (e) {}
    }
    const host = raw.replace(/^https?:\/\//i, '').replace(/\/.*$/, '').trim();
    if (!host) return ['*://*/*'];
    if (host.indexOf('*') >= 0) return ['*://' + host + '/*'];
    if (/^(\d{1,3}\.){3}\d{1,3}$/.test(host) || host === 'localhost' || host.indexOf(':') >= 0) {
      return ['*://' + host + '/*'];
    }
    const parts = host.split('.').filter(Boolean);
    if (parts.length > 2) return ['*://' + host + '/*'];
    return ['*://' + host + '/*', '*://*.' + host + '/*'];
  }

  function hostRuleToTampermonkeyMatch(rule) {
    const patterns = hostRuleToTampermonkeyMatchPatterns(rule);
    return patterns[0] || '*://*/*';
  }

  function stripTampermonkeyMatchLines(header) {
    return String(header || '').split(/\r?\n/).filter((line) => {
      const row = line.match(/^\s*\/\/\s*@([\w-]+)/);
      if (!row) return true;
      const key = String(row[1] || '').toLowerCase();
      return key !== 'match' && key !== 'include';
    }).join('\n');
  }

  function stripTampermonkeyDomainRuleLines(header) {
    return String(header || '').split(/\r?\n/).filter((line) => {
      const row = line.match(/^\s*\/\/\s*@([\w-]+)/);
      if (!row) return true;
      const key = String(row[1] || '').toLowerCase();
      return key !== 'match' && key !== 'include' && key !== 'exclude' && key !== 'connect';
    }).join('\n');
  }

  function formatTampermonkeyDomainRuleLine(rule) {
    const item = normalizeTampermonkeyDomainRuleEntry(rule);
    if (!item) return '';
    const label = item.type === 'match'
      ? 'match'
      : item.type === 'include'
        ? 'include'
        : item.type === 'exclude'
          ? 'exclude'
          : 'connect';
    const pad = ' '.repeat(Math.max(2, 13 - label.length));
    return '// @' + label + pad + item.value;
  }

  function updateTampermonkeyMetaDomainRules(code, domainRules, options) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    const opts = options && typeof options === 'object' ? options : {};
    const mode = ['manual', 'matches', 'all'].indexOf(String(opts.matchMode || '')) >= 0 ? String(opts.matchMode) : '';
    let rules = parseTampermonkeyDomainRulesInput(domainRules, 'match');
    if (mode === 'manual') {
      rules = [];
    } else if (mode === 'all' && !rules.some((rule) => rule.type === 'match' && rule.value === '*://*/*')) {
      rules = [{ type: 'match', value: '*://*/*' }].concat(rules);
    }
    let header = stripTampermonkeyDomainRuleLines(parsed.header);
    const lines = rules.map(formatTampermonkeyDomainRuleLine).filter(Boolean);
    if (lines.length) header = header.replace(/(\/\/\s*==\/UserScript==)/, lines.join('\n') + '\n$1');
    return header + parsed.body;
  }

  function updateTampermonkeyMetaMatchMode(code, matchMode, matchRules) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    const mode = ['manual', 'matches', 'all'].indexOf(String(matchMode || 'manual')) >= 0
      ? String(matchMode || 'manual')
      : 'manual';
    if (mode === 'manual') return String(code || '');
    let header = stripTampermonkeyMatchLines(parsed.header);
    const matchLines = [];
    if (mode === 'all') {
      matchLines.push('// @match        *://*/*');
    } else if (mode === 'matches') {
      const rules = (Array.isArray(matchRules) ? matchRules : String(matchRules || '').split(/[\n,，]+/))
        .map((x) => String(x || '').trim())
        .filter(Boolean);
      const source = rules.length ? rules : ['*'];
      const patterns = [];
      source.forEach((rule) => {
        hostRuleToTampermonkeyMatchPatterns(rule).forEach((pattern) => {
          if (patterns.indexOf(pattern) < 0) patterns.push(pattern);
        });
      });
      patterns.forEach((pattern) => {
        matchLines.push('// @match        ' + pattern);
      });
    }
    if (matchLines.length) {
      header = header.replace(/(\/\/\s*==\/UserScript==)/, matchLines.join('\n') + '\n$1');
    }
    return header + parsed.body;
  }

  function updateTampermonkeyMetaRunAt(code, runAt) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    const normalized = String(runAt || 'document_idle');
    const value = normalized === 'document_start'
      ? 'document-start'
      : normalized === 'document_end'
        ? 'document-end'
        : 'document-idle';
    const header = parsed.header;
    const lineRe = /^\s*\/\/\s*@run-at\s+.*/m;
    const nextLine = '// @run-at       ' + value;
    const nextHeader = lineRe.test(header)
      ? header.replace(lineRe, nextLine)
      : header.replace(/(\/\/\s*==\/UserScript==)/, nextLine + '\n$1');
    return nextHeader + parsed.body;
  }

  function updateTampermonkeyMetaNoframes(code, allFrames) {
    const parsed = parseTampermonkeyHeader(code);
    if (!parsed.hasMeta) return String(code || '');
    let header = String(parsed.header || '').split(/\r?\n/).filter((line) => !/^\s*\/\/\s*@noframes\b/i.test(line)).join('\n');
    if (allFrames === false) header = header.replace(/(\/\/\s*==\/UserScript==)/, '// @noframes\n$1');
    return header + parsed.body;
  }

  function createScriptFromTampermonkeyFile(text, fileName) {
    const parsed = parseTampermonkeyHeader(text);
    const now = Date.now();
    const script = applyTampermonkeyMetaToScript({
      id: '',
      name: (parsed.meta && parsed.meta.name) || String(fileName || '').replace(/\.user\.js$/i, '') || '',
      enabled: true,
      matchMode: 'manual',
      runAt: 'document_idle',
      world: 'USER_SCRIPT',
      allFrames: false,
      matches: [],
      code: String(text || ''),
      updatedAt: now,
    }, parsed);
    // 导入油猴脚本：无 @noframes 时保持与 Tampermonkey 一致（注入子 frame）
    script.allFrames = !(parsed.meta && parsed.meta.noframes);
    return script;
  }

  g.Hx0UserScriptCompat = {
    parseTampermonkeyHeader,
    extractTampermonkeyMatchConfig,
    extractTampermonkeyMatchRules,
    extractTampermonkeyDomainRules,
    parseTampermonkeyDomainRulesInput,
    formatTampermonkeyDomainRulesForEditor,
    inferTampermonkeyMatchModeFromRules,
    buildTampermonkeyDomainRulesForMatchMode,
    appendTampermonkeyHostToDomainRules,
    detectPreferredUserScriptWorld,
    scriptUsesMenuCommands,
    applyTampermonkeyMetaToScript,
    prepareUserScriptExecutionCode,
    prepareUserScriptRegistration,
    HX0_BUNDLED_JQUERY,
    isSuppressibleUserScriptError,
    isPlaceholderRequireError,
    stripTampermonkeyPlaceholderMeta,
    sanitizeUserScriptLastError,
    buildReadLastErrorProbeCode,
    createScriptFromTampermonkeyFile,
    getDefaultUserScriptCode,
    updateTampermonkeyMetaName,
    updateTampermonkeyMetaMatchMode,
    updateTampermonkeyMetaDomainRules,
    updateTampermonkeyMetaRunAt,
    updateTampermonkeyMetaNoframes,
    hostRuleToTampermonkeyMatch,
    hostRuleToTampermonkeyMatchPatterns,
    tampermonkeyMatchToHostRule,
  };
})(typeof globalThis !== 'undefined' ? globalThis : typeof self !== 'undefined' ? self : window);
