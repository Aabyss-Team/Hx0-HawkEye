/**
 * 供 chrome.scripting.executeScript 序列化注入到页面 MAIN 的纯函数。
 * 禁止加入 build-store 混淆：混淆体会引用 SW 内 stringArray 等辅助函数，目标页不存在 → 注入失败（dom_extract_failed / page_replay_failed）。
 */
globalThis.hx0DomPostFormSubmitInPage = function hx0DomPostFormSubmitInPage(actionUrl, pairs) {
  try {
    var f = document.createElement('form');
    f.method = 'POST';
    f.action = actionUrl;
    f.enctype = 'application/x-www-form-urlencoded';
    f.style.display = 'none';
    for (var i = 0; i < pairs.length; i++) {
      var inp = document.createElement('input');
      inp.type = 'hidden';
      inp.name = pairs[i].name;
      inp.value = pairs[i].value;
      f.appendChild(inp);
    }
    (document.body || document.documentElement).appendChild(f);
    f.submit();
    return true;
  } catch (e) {
    return false;
  }
};

globalThis.hx0DomPostIframeInPage = function hx0DomPostIframeInPage(actionUrl, pairs, decryptWaitMs) {
  return new Promise(function (resolve) {
    var done = false;
    function finish(ok, body, err) {
      if (done) return;
      done = true;
      if (ok) resolve({ ok: true, body: body || '' });
      else resolve({ ok: false, error: err || 'unknown' });
    }
    try {
      var iframe = document.createElement('iframe');
      iframe.name = 'hx0_dom_post_' + Date.now();
      iframe.style.cssText = 'position:fixed;width:1px;height:1px;left:-9999px;top:0;visibility:hidden;';
      var form = document.createElement('form');
      form.method = 'POST';
      form.action = actionUrl;
      form.target = iframe.name;
      form.enctype = 'application/x-www-form-urlencoded';
      form.style.display = 'none';
      for (var j = 0; j < pairs.length; j++) {
        var inp2 = document.createElement('input');
        inp2.type = 'hidden';
        inp2.name = pairs[j].name;
        inp2.value = pairs[j].value;
        form.appendChild(inp2);
      }
      document.body.appendChild(iframe);
      document.body.appendChild(form);
      iframe.onload = function () {
        setTimeout(function () {
          try {
            var doc = iframe.contentDocument;
            var html = doc && doc.documentElement ? doc.documentElement.outerHTML : '';
            iframe.remove();
            finish(true, html);
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            finish(false, '', String(e));
          }
        }, Math.min(decryptWaitMs, 5000));
      };
      form.submit();
      try {
        form.remove();
      } catch (e) {}
      setTimeout(function () {
        if (done) return;
        if (iframe.parentNode) {
          try {
            var doc2 = iframe.contentDocument;
            var html2 = doc2 && doc2.documentElement ? doc2.documentElement.outerHTML : '';
            iframe.remove();
            finish(true, html2);
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            finish(false, '', 'Timeout or cross-origin');
          }
        }
      }, 20000);
    } catch (e) {
      finish(false, '', String(e));
    }
  });
};

globalThis.hx0DomExtractInPage = function hx0DomExtractInPage(url, useIframe, decryptWaitMs) {
  return new Promise(function (resolve) {
    try {
      if (useIframe) {
        var iframe = document.createElement('iframe');
        iframe.style.cssText = 'position:fixed;width:1px;height:1px;left:-9999px;top:0;visibility:hidden;';
        iframe.src = url;
        document.body.appendChild(iframe);
        var doExtract = function () {
          try {
            var doc = iframe.contentDocument;
            var html = doc && doc.documentElement ? doc.documentElement.outerHTML : '';
            iframe.remove();
            resolve({ ok: true, body: html });
          } catch (e) {
            try {
              iframe.remove();
            } catch (err) {}
            resolve({ ok: false, error: String(e) });
          }
        };
        iframe.onload = function () {
          setTimeout(doExtract, Math.min(decryptWaitMs, 5000));
        };
        setTimeout(function () {
          if (iframe.parentNode) {
            try {
              var doc2 = iframe.contentDocument;
              var html2 = doc2 && doc2.documentElement ? doc2.documentElement.outerHTML : '';
              iframe.remove();
              resolve({ ok: true, body: html2 });
            } catch (e) {
              try {
                iframe.remove();
              } catch (err) {}
              resolve({ ok: false, error: 'Timeout or cross-origin' });
            }
          }
        }, 20000);
      } else {
        var html3 = document.documentElement ? document.documentElement.outerHTML : '';
        resolve({ ok: true, body: html3 });
      }
    } catch (e) {
      resolve({ ok: false, error: String(e) });
    }
  });
};

/** 页面上下文重放：在激活 Tab 内 fetch（与 background fetch 同源策略不同） */
globalThis.hx0PageContextReplayFetch = async function hx0PageContextReplayFetch(u, p) {
  try {
    var method = String((p && p.method) || 'GET').toUpperCase();
    var methodAutoFixed = !!p.methodAutoFixed;
    var body;
    if (p.bodyB64) {
      var bin = atob(p.bodyB64);
      var out = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
      body = out;
    } else {
      body = undefined;
    }
    if ((method === 'GET' || method === 'HEAD') && body !== undefined && body.byteLength > 0) {
      method = 'POST';
      methodAutoFixed = true;
    }
    var r = await fetch(u, {
      method: method,
      headers: p.headers || {},
      body: body,
      credentials: 'include',
      redirect: 'follow',
      cache: 'no-store',
    });
    var responseBody = await r.text();
    var headers = {};
    r.headers.forEach(function (v, k) {
      headers[k] = v;
    });
    return { ok: true, status: r.status, headers: headers, body: responseBody, methodAutoFixed: methodAutoFixed, methodSent: method };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
};

/**
 * 在页面 MAIN 环境执行用户脚本（与 DevTools Console 粘贴同一全局作用域）。
 * 勿用 new Function(code)() 包裹整段脚本：会在嵌套函数作用域里跑，Vue/AntD 表单 patch 可能与 Console 行为不一致。
 */
globalThis.hx0RunUserScriptInPage = function hx0RunUserScriptInPage(source) {
  var src = String(source || '');
  if (!src.trim()) return { ok: false, error: 'empty' };
  try {
    (0, eval)(src);
    return { ok: true, mode: 'eval' };
  } catch (e1) {
    try {
      var el = document.createElement('script');
      el.setAttribute('data-hx0-user-script', '1');
      el.textContent = src;
      (document.documentElement || document.head || document.body).appendChild(el);
      el.remove();
      return { ok: true, mode: 'script' };
    } catch (e2) {
      return { ok: false, error: String((e2 && e2.message) || e2 || (e1 && e1.message) || e1) };
    }
  }
};

/** 手动 MAIN 注入：首次执行 + DOM 变化后 debounce 重跑（适配 SPA 弹窗晚于页面加载挂载） */
globalThis.hx0RunUserScriptInPageWithRescan = function hx0RunUserScriptInPageWithRescan(source) {
  var src = String(source || '');
  if (!src.trim()) return { ok: false, error: 'empty' };
  function runOnce() {
    return globalThis.hx0RunUserScriptInPage(src);
  }
  var first = runOnce();
  if (!window.__hx0_spa_rescan_obs) {
    var timer;
    window.__hx0_spa_rescan_obs = new MutationObserver(function () {
      clearTimeout(timer);
      timer = setTimeout(runOnce, 300);
    });
    window.__hx0_spa_rescan_obs.observe(document.documentElement, { childList: true, subtree: true });
  }
  return Object.assign({}, first || { ok: true }, { rescan: true });
};

/** 在页面 MAIN 环境执行探测代码并返回结果（读取 localStorage / __hx0GmMenus__ 等） */
globalThis.hx0EvalUserScriptProbeInPage = function hx0EvalUserScriptProbeInPage(probeCode) {
  try {
    return (0, eval)(String(probeCode || ''));
  } catch (e) {
    return { ok: false, menus: [], error: String((e && e.message) || e) };
  }
};

/** 扩展 ISOLATED 环境执行用户脚本（Firefox scripting 须用 background 全局函数，禁止内联箭头函数） */
globalThis.hx0RunUserScriptInIsolated = function hx0RunUserScriptInIsolated(source) {
  var src = String(source || '');
  if (!src.trim()) return { ok: false, error: 'empty' };
  try {
    (0, eval)(src);
    return { ok: true, mode: 'eval' };
  } catch (e) {
    var message = String((e && e.message) || e);
    return {
      ok: false,
      error: message,
      cspBlocked: /Content Security Policy|unsafe-eval|Sink type mismatch|Trusted Types|blocked by CSP/i.test(message),
    };
  }
};

/** ISOLATED 环境探测（与 MAIN 探测逻辑相同，须为全局函数供 Firefox 序列化） */
globalThis.hx0EvalUserScriptProbeInIsolated = function hx0EvalUserScriptProbeInIsolated(probeCode) {
  return globalThis.hx0EvalUserScriptProbeInPage(probeCode);
};

/** Firefox 页面内 DOM 提取：同步返回当前文档 HTML（无 iframe 分支） */
globalThis.hx0DomExtractOuterHtmlSync = function hx0DomExtractOuterHtmlSync() {
  try {
    return document.documentElement ? document.documentElement.outerHTML : '';
  } catch (e) {
    return '';
  }
};
