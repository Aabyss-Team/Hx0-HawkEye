/* Firefox capture/intercept compat — restored from 5.23 */
const hx0FirefoxCaptureRuntime = typeof globalThis !== 'undefined' && globalThis.HX0_IS_FIREFOX_CAPTURE != null
  ? !!globalThis.HX0_IS_FIREFOX_CAPTURE
  : !!(typeof browser !== 'undefined' && browser.webRequest && browser.webRequest.filterResponseData);
const textEncoder = typeof TextEncoder !== 'undefined' ? new TextEncoder() : null;

const firefoxInterceptRequestIds = new Set();
const firefoxFilterByRecordId = new Map(); // recordId -> { filter, originalChunks, ... }
const firefoxPendingRequestByRecordId = new Map(); // recordId -> { resolve, timer, originalUrl, method, tabId, requestId }
const firefoxPendingRecordIdByRequestId = new Map(); // webRequest requestId -> firefox pending recordId
const firefoxFormResubmitTickets = []; // [{ recordId, tabId, url, method, expireAt }]
const firefoxFormResubmitRecordIdByRequestId = new Map(); // requestId -> recordId
const firefoxRedirectBypassList = []; // [{ url, tabId, method, expireAt }]
const FIREFOX_RESUBMIT_FORM_MESSAGE = 'HX0_FIREFOX_RESUBMIT_FORM';
const FIREFOX_FILTER_MAX_BYTES = 2 * 1024 * 1024; // 超过则自动透传，避免内存/稳定性问题
const FIREFOX_FORM_RESUBMIT_TTL_MS = 15000;
const DEFAULT_CAPTURE_TYPES = ['xhr_fetch', 'websocket', 'json', 'html', 'js', 'xml', 'other_text'];
let firefoxInterceptTypesCache = {
  types: DEFAULT_CAPTURE_TYPES.slice(),
  custom: [],
};

function concatUint8Chunks(chunks, totalBytes) {
  let expected = Number(totalBytes) || 0;
  if (expected <= 0) expected = (chunks || []).reduce((n, c) => n + ((c && c.byteLength) || 0), 0);
  const out = new Uint8Array(expected);
  let offset = 0;
  (chunks || []).forEach((chunk) => {
    if (!chunk || !chunk.byteLength) return;
    const remain = out.byteLength - offset;
    if (remain <= 0) return;
    const len = Math.min(remain, chunk.byteLength);
    out.set(chunk.subarray(0, len), offset);
    offset += len;
  });
  return offset === out.byteLength ? out : out.subarray(0, offset);
}

function decodeBytesToText(bytes, charsetHint) {
  try {
    const cs = String(charsetHint || '').trim() || 'utf-8';
    return new TextDecoder(cs, { fatal: false }).decode(bytes || new Uint8Array(0));
  } catch (e) {
    try {
      return new TextDecoder('utf-8', { fatal: false }).decode(bytes || new Uint8Array(0));
    } catch (e2) {
      return '';
    }
  }
}

function parseCharsetFromContentType(ct) {
  const m = /charset\s*=\s*["']?([^;"'\s]+)/i.exec(String(ct || ''));
  return m ? String(m[1] || '').trim() : 'utf-8';
}

function isIdentityContentEncoding(headers) {
  const ceHeader = (headers || []).find((h) => {
    const n = String((h && (h.name || h[0])) || '').toLowerCase();
    return n === 'content-encoding';
  });
  const ce = String((ceHeader && (ceHeader.value || ceHeader[1])) || '').toLowerCase().trim();
  if (!ce) return true;
  return ce === 'identity';
}
function consumeFirefoxRedirectBypass(url, tabId, method) {
  const now = Date.now();
  for (let i = firefoxRedirectBypassList.length - 1; i >= 0; i--) {
    const it = firefoxRedirectBypassList[i];
    if (!it || it.expireAt <= now) {
      firefoxRedirectBypassList.splice(i, 1);
      continue;
    }
    if (it.url === String(url || '') &&
      it.tabId === (tabId == null ? -1 : tabId) &&
      it.method === String(method || 'GET').toUpperCase()) {
      firefoxRedirectBypassList.splice(i, 1);
      return true;
    }
  }
  return false;
}

function addFirefoxRedirectBypass(url, tabId, method) {
  firefoxRedirectBypassList.push({
    url: String(url || ''),
    tabId: tabId == null ? -1 : tabId,
    method: String(method || 'GET').toUpperCase(),
    expireAt: Date.now() + 5000,
  });
}

function normalizeFirefoxComparableUrl(targetUrl) {
  try {
    return new URL(String(targetUrl || '')).href;
  } catch (e) {
    return String(targetUrl || '');
  }
}

function applyUrlEncodedBodyToGetUrl(targetUrl, bodyText) {
  const normalizedUrl = normalizeFirefoxComparableUrl(targetUrl);
  const body = String(bodyText == null ? '' : bodyText);
  if (!body) return normalizedUrl;
  try {
    const parsed = new URL(normalizedUrl);
    const params = new URLSearchParams(body);
    params.forEach((value, key) => parsed.searchParams.append(String(key), String(value)));
    return parsed.toString();
  } catch (e) {
    return normalizedUrl;
  }
}

function cleanupFirefoxFormResubmitTickets(now) {
  const ts = Number(now) || Date.now();
  for (let i = firefoxFormResubmitTickets.length - 1; i >= 0; i--) {
    const item = firefoxFormResubmitTickets[i];
    if (!item || Number(item.expireAt || 0) <= ts) {
      firefoxFormResubmitTickets.splice(i, 1);
    }
  }
}

function removeFirefoxFormResubmitTicketsByRecordId(recordId) {
  const rid = String(recordId || '').trim();
  if (!rid) return;
  for (let i = firefoxFormResubmitTickets.length - 1; i >= 0; i--) {
    const item = firefoxFormResubmitTickets[i];
    if (item && String(item.recordId || '') === rid) firefoxFormResubmitTickets.splice(i, 1);
  }
}

function registerFirefoxFormResubmitTicket(recordId, tabId, targetUrl, method) {
  const numericTabId = Number(tabId);
  const rid = String(recordId || '').trim();
  if (!rid || !Number.isFinite(numericTabId)) return;
  cleanupFirefoxFormResubmitTickets(Date.now());
  removeFirefoxFormResubmitTicketsByRecordId(rid);
  firefoxFormResubmitTickets.push({
    recordId: rid,
    tabId: numericTabId,
    url: normalizeFirefoxComparableUrl(targetUrl),
    method: String(method || 'GET').toUpperCase(),
    expireAt: Date.now() + FIREFOX_FORM_RESUBMIT_TTL_MS,
  });
}

function claimFirefoxFormResubmitRecordId(requestId, tabId, targetUrl, method) {
  const requestKey = String(requestId || '').trim();
  if (!requestKey) return '';
  const existing = firefoxFormResubmitRecordIdByRequestId.get(requestKey);
  if (existing) return String(existing || '');
  const numericTabId = Number(tabId);
  if (!Number.isFinite(numericTabId)) return '';
  cleanupFirefoxFormResubmitTickets(Date.now());
  const normalizedUrl = normalizeFirefoxComparableUrl(targetUrl);
  const methodUc = String(method || 'GET').toUpperCase();
  for (let i = 0; i < firefoxFormResubmitTickets.length; i++) {
    const item = firefoxFormResubmitTickets[i];
    if (!item) continue;
    if (Number(item.tabId) !== numericTabId) continue;
    if (String(item.method || 'GET').toUpperCase() !== methodUc) continue;
    if (String(item.url || '') !== normalizedUrl) continue;
    const rid = String(item.recordId || '').trim();
    firefoxFormResubmitTickets.splice(i, 1);
    if (!rid) return '';
    firefoxFormResubmitRecordIdByRequestId.set(requestKey, rid);
    firefoxPendingRecordIdByRequestId.set(requestKey, rid);
    requestIdToHookIdMap.set(requestKey, rid);
    return rid;
  }
  return '';
}

function clearFirefoxFormResubmitRequestId(requestId) {
  const requestKey = String(requestId || '').trim();
  if (!requestKey) return;
  firefoxFormResubmitRecordIdByRequestId.delete(requestKey);
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    try {
      if (!chrome.tabs || !chrome.tabs.sendMessage) {
        reject(new Error('tabs_send_message_unavailable'));
        return;
      }
      chrome.tabs.sendMessage(tabId, message, (res) => {
        try {
          if (chrome.runtime && chrome.runtime.lastError) {
            reject(new Error(String(chrome.runtime.lastError.message || 'tabs_send_message_failed')));
            return;
          }
        } catch (e) {}
        resolve(res);
      });
    } catch (e) {
      reject(e);
    }
  });
}

function buildFallbackAcceptLanguagePreview() {
  let langs = [];
  try {
    if (typeof navigator !== 'undefined' && Array.isArray(navigator.languages) && navigator.languages.length) {
      langs = navigator.languages.filter(Boolean).map((x) => String(x));
    }
  } catch (e) {}
  if (!langs.length) {
    try {
      if (typeof navigator !== 'undefined' && navigator.language) langs = [String(navigator.language)];
    } catch (e) {}
  }
  if (!langs.length) return '';
  return langs.slice(0, 6).map((lang, idx) => {
    if (idx === 0) return lang;
    const q = Math.max(0.1, 1 - (idx * 0.1));
    return lang + ';q=' + q.toFixed(1).replace(/\.0$/, '');
  }).join(',');
}

function inferFirefoxPreviewSecFetchSite(targetUrl, refererUrl) {
  if (!refererUrl) return 'none';
  try {
    const targetOrigin = new URL(String(targetUrl || '')).origin;
    const refererOrigin = new URL(String(refererUrl || '')).origin;
    return targetOrigin === refererOrigin ? 'same-origin' : 'cross-site';
  } catch (e) {
    return 'same-origin';
  }
}

function inferFirefoxPreviewSecFetchDest(detailsType) {
  const dt = String(detailsType || '').toLowerCase();
  if (dt === 'main_frame') return 'document';
  if (dt === 'sub_frame') return 'iframe';
  if (dt === 'stylesheet') return 'style';
  if (dt === 'script') return 'script';
  if (dt === 'image') return 'image';
  if (dt === 'font') return 'font';
  if (dt === 'object') return 'object';
  return 'empty';
}

function getReplayHeaderValueCiFromObject(headersObj, nameLc) {
  if (!headersObj || typeof headersObj !== 'object') return '';
  const key = Object.keys(headersObj).find((k) => String(k || '').toLowerCase() === String(nameLc || '').toLowerCase());
  return key ? String(headersObj[key] || '') : '';
}

function capturedHeadersToObject(headersArr) {
  const out = {};
  normalizeCapturedRequestHeaders(headersArr).forEach(([key, value]) => {
    if (!key) return;
    out[String(key)] = String(value);
  });
  return out;
}

function buildFirefoxFallbackPreviewHeaders(details, bodyText, overrideHeaders) {
  const out = [];
  const headersObj = normalizeReplayHeaders(overrideHeaders || {});
  const targetUrl = String((details && details.url) || '');
  const method = String((details && details.method) || 'GET').toUpperCase();
  const dt = String((details && details.type) || '').toLowerCase();
  let parsedTarget = null;
  try { parsedTarget = new URL(targetUrl); } catch (e) { parsedTarget = null; }
  const refererUrl = String((details && (details.documentUrl || details.originUrl)) || '');
  const host = parsedTarget ? parsedTarget.host : '';
  const bodyString = String(bodyText == null ? '' : bodyText);
  const contentType =
    getReplayHeaderValueCiFromObject(headersObj, 'content-type') ||
    (((details && details.requestBody && details.requestBody.formData) || (bodyString && method !== 'GET' && method !== 'HEAD'))
      ? 'application/x-www-form-urlencoded'
      : '');
  const bodyIsBinaryLike =
    looksLikeMultipartFormDataBody(bodyString) ||
    /multipart\/form-data/i.test(contentType) ||
    /application\/octet-stream/i.test(contentType) ||
    /^image\//i.test(contentType) ||
    /^audio\//i.test(contentType) ||
    /^video\//i.test(contentType);
  const contentLength = method === 'GET' || method === 'HEAD'
    ? ''
    : String(bodyIsBinaryLike ? bodyString.length : (textEncoder ? textEncoder.encode(bodyString).length : bodyString.length));
  const originHeader =
    getReplayHeaderValueCiFromObject(headersObj, 'origin') ||
    (refererUrl ? (() => { try { return new URL(refererUrl).origin; } catch (e) { return ''; } })() : '');
  const userAgentHeader = getReplayHeaderValueCiFromObject(headersObj, 'user-agent') || (() => {
    try { return typeof navigator !== 'undefined' ? String(navigator.userAgent || '') : ''; } catch (e) { return ''; }
  })();
  const acceptHeader =
    getReplayHeaderValueCiFromObject(headersObj, 'accept') ||
    ((dt === 'main_frame' || dt === 'sub_frame')
      ? 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
      : '*/*');
  const acceptLanguageHeader =
    getReplayHeaderValueCiFromObject(headersObj, 'accept-language') ||
    buildFallbackAcceptLanguagePreview();
  const acceptEncodingHeader =
    getReplayHeaderValueCiFromObject(headersObj, 'accept-encoding') ||
    'gzip, deflate, br, zstd';
  const secFetchDest = getReplayHeaderValueCiFromObject(headersObj, 'sec-fetch-dest') || inferFirefoxPreviewSecFetchDest(dt);
  const secFetchMode = getReplayHeaderValueCiFromObject(headersObj, 'sec-fetch-mode') || ((dt === 'main_frame' || dt === 'sub_frame') ? 'navigate' : 'cors');
  const secFetchSite =
    getReplayHeaderValueCiFromObject(headersObj, 'sec-fetch-site') ||
    inferFirefoxPreviewSecFetchSite(targetUrl, refererUrl);
  const secFetchUser =
    getReplayHeaderValueCiFromObject(headersObj, 'sec-fetch-user') ||
    ((dt === 'main_frame' || dt === 'sub_frame') ? '?1' : '');
  const refererHeader = getReplayHeaderValueCiFromObject(headersObj, 'referer') || refererUrl;

  if (host) out.push(['Host', host]);
  if (userAgentHeader) out.push(['User-Agent', userAgentHeader]);
  if (acceptHeader) out.push(['Accept', acceptHeader]);
  if (acceptLanguageHeader) out.push(['Accept-Language', acceptLanguageHeader]);
  if (acceptEncodingHeader) out.push(['Accept-Encoding', acceptEncodingHeader]);
  if (refererHeader) out.push(['Referer', refererHeader]);
  if (contentType) out.push(['Content-Type', contentType]);
  if (contentLength) out.push(['Content-Length', contentLength]);
  if (originHeader && method !== 'GET' && method !== 'HEAD') out.push(['Origin', originHeader]);
  out.push(['Connection', getReplayHeaderValueCiFromObject(headersObj, 'connection') || 'keep-alive']);
  if (dt === 'main_frame' || dt === 'sub_frame') {
    out.push(['Upgrade-Insecure-Requests', getReplayHeaderValueCiFromObject(headersObj, 'upgrade-insecure-requests') || '1']);
    if (secFetchDest) out.push(['Sec-Fetch-Dest', secFetchDest]);
    if (secFetchMode) out.push(['Sec-Fetch-Mode', secFetchMode]);
    if (secFetchSite) out.push(['Sec-Fetch-Site', secFetchSite]);
    if (secFetchUser) out.push(['Sec-Fetch-User', secFetchUser]);
  }
  return out;
}

function finalizeFirefoxFilterIntercept(recordId, action, payload) {
  const st = firefoxFilterByRecordId.get(recordId);
  if (!st) return false;
  try {
    const filter = st.filter;
    if (!filter) {
      firefoxFilterByRecordId.delete(recordId);
      return false;
    }
    let outBytes = null;
    if (action === 'drop') {
      outBytes = new Uint8Array(0);
    } else if (payload && typeof payload === 'object' && (payload.responseBody !== undefined || payload.body !== undefined)) {
      const text = payload.responseBody !== undefined
        ? String(payload.responseBody == null ? '' : payload.responseBody)
        : String(payload.body == null ? '' : payload.body);
      outBytes = textEncoder ? textEncoder.encode(text) : new Uint8Array(0);
    } else {
      outBytes = concatUint8Chunks(st.originalChunks || [], st.totalBytes || 0);
    }
    try {
      if (outBytes && outBytes.byteLength) filter.write(outBytes);
      filter.close();
    } catch (e) {
      try { filter.disconnect(); } catch (e2) {}
    }
    firefoxInterceptRequestIds.delete(st.requestId);
    firefoxFilterByRecordId.delete(recordId);
    return true;
  } catch (e) {
    try {
      st.filter && st.filter.disconnect && st.filter.disconnect();
    } catch (e2) {}
    firefoxInterceptRequestIds.delete(st.requestId);
    firefoxFilterByRecordId.delete(recordId);
    return false;
  }
}

async function releaseFirefoxEditedRequestViaPageReplay(st, recordId, opts) {
  const effectiveReplayUrl = String((opts && opts.effectiveReplayUrl) || '');
  const nextMethod = String((opts && opts.nextMethod) || 'POST').toUpperCase();
  const nextBody = String((opts && opts.nextBody) == null ? '' : opts.nextBody);
  const persistedRequestBody = (opts && opts.persistedRequestBody != null) ? String(opts.persistedRequestBody) : nextBody;
  const previewHeaders = (opts && opts.previewHeaders) || [];
  const headersObj = capturedHeadersToObject(previewHeaders);
  try {
    await patchReleasedInterceptRecord(recordId, {
      url: effectiveReplayUrl,
      method: nextMethod,
      requestHeaders: headersObj,
      requestBody: persistedRequestBody,
    }, { isResponse: false });
  } catch (e) {}
  if (typeof registerToolingInterceptBypassWindow === 'function') {
    registerToolingInterceptBypassWindow(st.tabId, effectiveReplayUrl, {
      allowAllUrls: false,
      allowSameOrigin: false,
      ttlMs: Math.max(typeof PAGE_REPLAY_BYPASS_TTL_MS !== 'undefined' ? PAGE_REPLAY_BYPASS_TTL_MS : 12000, 4000),
      matchLimit: 4,
    });
  }
  if (typeof registerPageReplayBypassTicket === 'function') {
    registerPageReplayBypassTicket(effectiveReplayUrl, nextMethod);
  }
  if (typeof replayByPageContext !== 'function') {
    throw new Error('page_context_replay_unavailable');
  }
  const replayResult = await replayByPageContext(effectiveReplayUrl, {
    url: effectiveReplayUrl,
    method: nextMethod,
    headers: headersObj,
    body: nextBody,
  }, st.tabId);
  if (!replayResult || !replayResult.ok) {
    throw new Error(String((replayResult && replayResult.error) || 'firefox_page_replay_failed'));
  }
  try {
    await patchReleasedInterceptRecord(recordId, {
      statusCode: replayResult.status,
      responseHeaders: replayResult.headers || {},
      responseBody: replayResult.body || '',
    }, { isResponse: true });
  } catch (e) {}
  try {
    const respHeaders = replayResult.headers && typeof replayResult.headers === 'object' ? replayResult.headers : {};
    const respCt = String(respHeaders['content-type'] || respHeaders['Content-Type'] || '');
    const frameType = String(st.detailsType || '').toLowerCase();
    if ((frameType === 'main_frame' || frameType === 'sub_frame') && replayResult.body && /text\/html/i.test(respCt)) {
      await sendMessageToTab(st.tabId, {
        type: 'HX0_FIREFOX_APPLY_NAVIGATION_HTML',
        payload: { html: String(replayResult.body || ''), url: effectiveReplayUrl },
      });
    }
  } catch (e) {}
  return replayResult;
}

async function finalizeFirefoxRequestIntercept(recordId, action, payload) {
  const st = firefoxPendingRequestByRecordId.get(recordId);
  if (!st) return false;
  const cleanupState = () => {
    try { if (st.timer) clearTimeout(st.timer); } catch (e) {}
    if (st.requestId) firefoxPendingRecordIdByRequestId.delete(st.requestId);
    if (st.requestId) clearFirefoxFormResubmitRequestId(st.requestId);
    firefoxPendingRequestByRecordId.delete(recordId);
  };
  try {
    const resolve = st.resolve;
    if (action === 'drop') {
      cleanupState();
      try { resolve({ cancel: true }); } catch (e) {}
      return true;
    }

    const nextUrl = payload && payload.url ? String(payload.url) : String(st.originalUrl || '');
    const nextMethod = payload && payload.method
      ? String(payload.method).toUpperCase()
      : String(st.method || 'GET').toUpperCase();
    const nextHeadersObj = normalizeReplayHeaders(
      (payload && (payload.requestHeaders || payload.headers))
      || capturedHeadersToObject(st.requestHeadersPreview || [])
    );
    const nextBody = (payload && (payload.requestBody !== undefined || payload.body !== undefined))
      ? String(payload.requestBody !== undefined ? payload.requestBody : payload.body)
      : String(st.originalRequestBody || '');
    const persistedRequestBody = (nextMethod === 'GET' || nextMethod === 'HEAD') ? '' : nextBody;
    const urlChanged = nextUrl && nextUrl !== String(st.originalUrl || '');
    const methodChanged = nextMethod !== String(st.method || 'GET').toUpperCase();
    const bodyChanged = nextBody !== String(st.originalRequestBody || '');
    const hasEditedHeaders = !!(payload && (payload.requestHeaders || payload.headers));
    const contentType = getReplayHeaderValueCiFromObject(nextHeadersObj, 'content-type');
    const multipartEditedBody = looksLikeMultipartFormDataBody(nextBody);
    const canResubmitAsForm = !!(
      (st.detailsType === 'main_frame' || st.detailsType === 'sub_frame') &&
      (nextMethod === 'GET' || nextMethod === 'POST') &&
      (
        !contentType ||
        /application\/x-www-form-urlencoded/i.test(contentType) ||
        /multipart\/form-data/i.test(contentType) ||
        multipartEditedBody
      )
    );

    if (canResubmitAsForm && (urlChanged || methodChanged || bodyChanged || hasEditedHeaders)) {
      const effectiveReplayUrl = nextMethod === 'GET'
        ? applyUrlEncodedBodyToGetUrl(nextUrl, nextBody)
        : nextUrl;
      const previewHeadersSeed = normalizeReplayHeaders(nextHeadersObj || {});
      ensureMultipartContentTypeInHeaders(previewHeadersSeed, nextBody);
      const previewHeaders = buildFirefoxFallbackPreviewHeaders({
        url: effectiveReplayUrl,
        method: nextMethod,
        type: st.detailsType,
        requestBody: persistedRequestBody
          ? (/multipart\/form-data/i.test(getReplayHeaderValueCiFromObject(previewHeadersSeed, 'content-type') || '') || multipartEditedBody
            ? null
            : { formData: {} })
          : null,
        documentUrl: st.documentUrl,
        originUrl: st.originUrl,
      }, nextBody, previewHeadersSeed);
      const useMultipartPageReplay = multipartEditedBody || /multipart\/form-data/i.test(contentType);
      if (useMultipartPageReplay) {
        await releaseFirefoxEditedRequestViaPageReplay(st, recordId, {
          effectiveReplayUrl,
          nextMethod,
          nextBody,
          persistedRequestBody,
          previewHeaders,
        });
        cleanupState();
        try { resolve({ cancel: true }); } catch (e) {}
        return true;
      }
      try {
        await patchReleasedInterceptRecord(recordId, {
          url: effectiveReplayUrl,
          method: nextMethod,
          requestHeaders: capturedHeadersToObject(previewHeaders),
          requestBody: persistedRequestBody,
        }, { isResponse: false });
      } catch (e) {}
      registerFirefoxFormResubmitTicket(recordId, st.tabId, effectiveReplayUrl, nextMethod);
      let submitAck = null;
      try {
        submitAck = await sendMessageToTab(st.tabId, {
          type: FIREFOX_RESUBMIT_FORM_MESSAGE,
          payload: {
            url: nextUrl,
            method: nextMethod,
            body: nextBody,
            contentType: getReplayHeaderValueCiFromObject(previewHeadersSeed, 'content-type') || contentType || '',
            delayMs: 40,
          },
        });
      } catch (e) {
        removeFirefoxFormResubmitTicketsByRecordId(recordId);
        throw e;
      }
      if (!submitAck || submitAck.ok !== true) {
        removeFirefoxFormResubmitTicketsByRecordId(recordId);
        throw new Error(String((submitAck && submitAck.error) || 'firefox_form_resubmit_failed'));
      }
      cleanupState();
      try { resolve({ cancel: true }); } catch (e) {}
      return true;
    }

    const result = {};
    if (urlChanged) {
      addFirefoxRedirectBypass(nextUrl, st.tabId, st.method);
      result.redirectUrl = nextUrl;
    }
    cleanupState();
    try { resolve(result); } catch (e) {}
    return true;
  } catch (e) {
    removeFirefoxFormResubmitTicketsByRecordId(recordId);
    return false;
  }
}

function canUseFirefoxHardDebuggerIntercept(tabId) {
  try {
    return !!(
      !hx0FirefoxCaptureRuntime &&
      typeof chrome !== 'undefined' &&
      chrome.debugger &&
      tabId != null &&
      tabId >= 0 &&
      debuggerAttachedTabId != null &&
      debuggerAttachedTabId === tabId
    );
  } catch (e) {
    return false;
  }
}
async function patchRecordedRequestHeaders(recordId, requestHeaders) {
  if (!recordId || typeof HawkEyeStorage === 'undefined' || !HawkEyeStorage.getRequest || !HawkEyeStorage.patchRequest) return false;
  for (let i = 0; i < 8; i++) {
    let rec = null;
    try { rec = await HawkEyeStorage.getRequest(recordId); } catch (e) { rec = null; }
    if (!rec) {
      await new Promise((resolve) => setTimeout(resolve, 25));
      continue;
    }
    if (headerPairsEqual(rec.requestHeaders || [], requestHeaders || [])) return true;
    const hits = detectSensitiveHits({
      url: rec.url,
      requestHeaders: requestHeaders || [],
      requestBody: rec.requestBody || '',
      responseHeaders: rec.responseHeaders || [],
      responseBody: rec.responseBody || '',
    });
    try {
      await HawkEyeStorage.patchRequest(recordId, {
        requestHeaders: normalizeCapturedRequestHeaders(requestHeaders),
        sensitiveHits: hits,
      });
      try {
        chrome.runtime.sendMessage({
          type: HX0C.MESSAGE.SIDEPANEL_DATA_CHANGED || 'SIDEPANEL_DATA_CHANGED',
          reason: 'record_headers_patched',
          id: recordId,
        });
      } catch (e2) {}
      return true;
    } catch (e) {
      return false;
    }
  }
  return false;
}

try {
  if (hx0FirefoxCaptureRuntime && typeof browser !== 'undefined' && browser.webRequest && browser.webRequest.onBeforeRequest) {
    browser.webRequest.onBeforeRequest.addListener(
      (details) => {
        if (!interceptModeEnabled) return {};
        if (details.tabId == null || details.tabId < 0) return {};
        const firefoxResubmitRecordId = claimFirefoxFormResubmitRecordId(details.requestId, details.tabId, details.url, details.method);
        if (firefoxResubmitRecordId) return {};
        if (isToolingInterceptBypassed(details.tabId, details.url)) return {};
        if (isExtensionUrl(details.url)) return {};
        const dt = String(details.type || '').toLowerCase();
        if (dt === 'xmlhttprequest' || dt === 'fetch') return {};
        if (canUseFirefoxHardDebuggerIntercept(details.tabId)) return {};
        if (consumeFirefoxRedirectBypass(details.url, details.tabId, details.method)) return {};
        let host = '';
        try { host = new URL(details.url).hostname; } catch (e) {}
        if (!hostMatchesRules(host, interceptHostRules)) return {};

        let resourceType = webRequestTypeToResourceType(details.type);
        if (resourceType == null || resourceType === 'other') resourceType = inferInterceptResourceTypeFromUrl(details.url);
        const channel = dt === 'xmlhttprequest' ? 'xhr' : (dt === 'fetch' ? 'fetch' : 'webrequest');
        const cached = firefoxInterceptTypesCache || {};
        if (!shouldCaptureByFilter(details.url, resourceType || 'other', channel, cached.types || DEFAULT_CAPTURE_TYPES, cached.custom || [])) return {};

        return new Promise((resolve) => {
          const recordId = 'ff_req_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
          const method = String(details.method || 'GET').toUpperCase();
          const requestBodyRaw = requestBodyToText(details.requestBody || null);
          const hookCapture = findRecentHookMultipartBodyCapture('', details.tabId, details.url, method);
          const requestBodyText = hookCapture && shouldReplaceCapturedRequestBody(requestBodyRaw, hookCapture.requestBody)
            ? String(hookCapture.requestBody || '')
            : requestBodyRaw;
          const previewHeaders = buildFirefoxFallbackPreviewHeaders(
            details,
            requestBodyText,
            hookCapture && hookCapture.requestHeaders && hookCapture.requestHeaders.length
              ? capturedHeadersToObject(hookCapture.requestHeaders)
              : {}
          );
          const timer = setTimeout(() => {
            const st = firefoxPendingRequestByRecordId.get(recordId);
            if (!st) return;
            try { st.resolve({}); } catch (e) {}
            if (st.requestId) firefoxPendingRecordIdByRequestId.delete(st.requestId);
            if (st.requestId) clearFirefoxFormResubmitRequestId(st.requestId);
            firefoxPendingRequestByRecordId.delete(recordId);
            interceptQueue = interceptQueue.filter((x) => x !== recordId);
            try { chrome.runtime.sendMessage({ type: HX0C.MESSAGE.SIDEPANEL_DATA_CHANGED || 'SIDEPANEL_DATA_CHANGED', reason: 'intercept_timeout', id: recordId }); } catch (e) {}
          }, 120000);

          firefoxPendingRequestByRecordId.set(recordId, {
            resolve,
            timer,
            originalUrl: details.url,
            method,
            tabId: details.tabId,
            requestId: details.requestId,
            detailsType: String(details.type || '').toLowerCase(),
            originalRequestBody: requestBodyText,
            requestHeadersPreview: previewHeaders,
            documentUrl: details.documentUrl || '',
            originUrl: details.originUrl || '',
          });
          firefoxPendingRecordIdByRequestId.set(details.requestId, recordId);
          requestIdToHookIdMap.set(details.requestId, recordId);

          (async () => {
            try {
              if (typeof HawkEyeStorage !== 'undefined' && HawkEyeStorage.addRequest) {
                await HawkEyeStorage.addRequest({
                  id: recordId,
                  url: details.url,
                  method,
                  requestHeaders: previewHeaders,
                  requestBody: requestBodyText,
                  responseHeaders: [],
                  responseBody: '',
                  statusCode: 0,
                  tabId: details.tabId,
                  detailsType: details.type || '',
                  resourceType: resourceType || 'other',
                  channelType: 'firefox_request',
                  mimeType: '',
                  host,
                  durationMs: 0,
                  sizeBytes: 0,
                  viewport: '',
                  sensitiveHits: [],
                });
              }
              rememberRecentDebuggerInterceptRecord({
                recordId,
                tabId: details.tabId,
                url: details.url,
                method,
                timeStamp: Date.now(),
              });
              interceptQueue.push(recordId);
              onRecordAdded(recordId, host);
            } catch (e) {
              const st = firefoxPendingRequestByRecordId.get(recordId);
              if (!st) return;
              try { st.resolve({}); } catch (e2) {}
              clearTimeout(st.timer);
              if (st.requestId) firefoxPendingRecordIdByRequestId.delete(st.requestId);
              if (st.requestId) clearFirefoxFormResubmitRequestId(st.requestId);
              firefoxPendingRequestByRecordId.delete(recordId);
            }
          })();
        });
      },
      { urls: ['<all_urls>'] },
      ['blocking', 'requestBody']
    );
  }
} catch (e) {}
try {
  chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
      let requestHeaders = details.requestHeaders || [];
      const replayOverrideTicket = hx0FirefoxCaptureRuntime && /^https?:\/\//i.test(details.url || '')
        ? findReplayHeaderOverrideTicket(details)
        : null;
      if (replayOverrideTicket) {
        requestHeaders = applyReplayHeaderOverridesToRequestHeaders(requestHeaders, replayOverrideTicket.headers);
      }
      if (
        hx0FirefoxCaptureRuntime &&
        /^https?:\/\//i.test(details.url || '') &&
        findReplayHeaderSanitizeTicket(details.url, details.method || '') &&
        (isExtensionContextRequest(details) || hasExtensionFingerprintHeader(requestHeaders))
      ) {
        let strippedHeaders = stripReplayFingerprintHeadersFromRequestHeaders(requestHeaders);
        if (replayOverrideTicket) strippedHeaders = applyReplayHeaderOverridesToRequestHeaders(strippedHeaders, replayOverrideTicket.headers);
        return { requestHeaders: strippedHeaders };
      }
      const split = splitInternalHookHeaders(requestHeaders);
      let reqHeaders = split.blockingHeaders.slice();
      if (replayOverrideTicket) reqHeaders = applyReplayHeaderOverridesToRequestHeaders(reqHeaders, replayOverrideTicket.headers);
      const hookRecordId = split.hookRecordId || bindHookRecordIdForRequest(details);
      const hasHookBypass = !!split.hasHookBypass;
      const firefoxPendingRecordId = firefoxPendingRecordIdByRequestId.get(details.requestId) || '';
      if (hookRecordId) requestIdToHookIdMap.set(details.requestId, hookRecordId);
      if (hookRecordId) rememberObservedHookRequestHeaders(hookRecordId, split.visibleHeaders);
      const pendingMeta = pendingRequests.get(details.requestId);
      if (pendingMeta) pendingMeta.requestHeaders = pickRicherCapturedHeaders(pendingMeta.requestHeaders || [], split.visibleHeaders);
      if (isToolingInterceptBypassed(details.tabId, details.url)) {
        if (firefoxPendingRecordId) {
          patchRecordedRequestHeaders(firefoxPendingRecordId, reqHeaders).catch(() => {});
        }
        if (hookRecordId || hasHookBypass) return { requestHeaders: reqHeaders };
        if (replayOverrideTicket) return { requestHeaders: reqHeaders };
        return;
      }
      const forceForHook = !!hookRecordId || hasHookBypass;
      const forceForIntercept = (() => {
        if (!hx0FirefoxCaptureRuntime) return false;
        if (!interceptModeEnabled) return false;
        if (details.tabId == null || details.tabId < 0) return false;
        let host = '';
        try { host = new URL(details.url).hostname; } catch (e) {}
        return hostMatchesRules(host, interceptHostRules);
      })();
      if (!forceForHook && !forceForIntercept) {
        // 仅用于抹除内部追踪头，避免泄漏到服务端
        if (hookRecordId) return { requestHeaders: reqHeaders };
        if (replayOverrideTicket) return { requestHeaders: reqHeaders };
        return;
      }
      if (hx0FirefoxCaptureRuntime && (forceForHook || forceForIntercept)) {
        let replaced = false;
        for (let i = 0; i < reqHeaders.length; i++) {
          if (String(reqHeaders[i].name || '').toLowerCase() === 'accept-encoding') {
            reqHeaders[i] = { name: reqHeaders[i].name, value: 'identity' };
            replaced = true;
            break;
          }
        }
        if (!replaced) reqHeaders.push({ name: 'Accept-Encoding', value: 'identity' });
      }
      if (firefoxPendingRecordId) {
        patchRecordedRequestHeaders(firefoxPendingRecordId, reqHeaders).catch(() => {});
      }
      return { requestHeaders: reqHeaders };
    },
    { urls: ['<all_urls>'] },
    ['blocking', 'requestHeaders']
  );
} catch (e) {}
try {
  chrome.webRequest.onHeadersReceived.addListener(
    (details) => {
      if (!hx0FirefoxCaptureRuntime) return {};
      const p = pendingRequests.get(details.requestId);
      const hookRecordId = requestIdToHookIdMap.get(details.requestId) || '';
      const reuseRecordId = (p && p.reuseRecordId) ? String(p.reuseRecordId) : '';
      const effectiveRecordId = hookRecordId || reuseRecordId;
      if (!interceptModeEnabled && !effectiveRecordId) return {};
      if (details.tabId == null || details.tabId < 0) return {};
      if (isToolingInterceptBypassed(details.tabId, details.url)) return {};
      if (isExtensionUrl(details.url)) return {};
      let host = '';
      try { host = new URL(details.url).hostname; } catch (e) {}
      if (!effectiveRecordId && !hostMatchesRules(host, interceptHostRules)) return {};

      const dt = String(details.type || '').toLowerCase();
      const mime = getMimeFromResponseHeaders(details.responseHeaders || []);
      const resourceType = inferResourceType(details.url, mime);
      // 逐步放开到 HTML/JSON/XML，且严格遵循用户勾选类型
      if (!effectiveRecordId && resourceType !== 'html' && resourceType !== 'json' && resourceType !== 'xml') return {};
      if (resourceType === 'html') {
        if (dt !== 'main_frame' && dt !== 'sub_frame' && dt !== 'xmlhttprequest' && dt !== 'fetch') return {};
      } else if (!effectiveRecordId && dt !== 'xmlhttprequest' && dt !== 'fetch') {
        return {};
      }
      const channel = dt === 'xmlhttprequest' ? 'xhr' : (dt === 'fetch' ? 'fetch' : 'webrequest');
      const cached = firefoxInterceptTypesCache || {};
      if (!effectiveRecordId && !shouldCaptureByFilter(details.url, resourceType, channel, cached.types || DEFAULT_CAPTURE_TYPES, cached.custom || [])) return {};
      if (!isIdentityContentEncoding(details.responseHeaders || [])) return {};

      let filter = null;
      try {
        const api = typeof browser !== 'undefined' && browser.webRequest && browser.webRequest.filterResponseData
          ? browser
          : chrome;
        filter = api.webRequest.filterResponseData(details.requestId);
      } catch (e) {
        return {};
      }
      if (!filter) return {};

      firefoxInterceptRequestIds.add(details.requestId);
      const state = {
        requestId: details.requestId,
        tabId: details.tabId,
        url: details.url,
        method: (details.method || 'GET').toUpperCase(),
        statusCode: details.statusCode || 0,
        responseHeaders: details.responseHeaders || [],
        mimeType: mime,
        resourceType,
        host,
        filter,
        originalChunks: [],
        totalBytes: 0,
        charset: parseCharsetFromContentType(mime),
        recordId: '',
        originalText: '',
        passThrough: false,
        hookRecordId: effectiveRecordId,
      };

      filter.ondata = (event) => {
        try {
          if (state.passThrough) {
            filter.write(event.data);
            return;
          }
          const src = new Uint8Array(event.data || new ArrayBuffer(0));
          const copy = new Uint8Array(src.byteLength);
          copy.set(src);
          state.originalChunks.push(copy);
          state.totalBytes += copy.byteLength;
          if (state.totalBytes > FIREFOX_FILTER_MAX_BYTES) {
            // 超限自动透传，避免内容进程内存压力
            state.passThrough = true;
            const raw = concatUint8Chunks(state.originalChunks, state.totalBytes);
            state.originalChunks = [];
            state.totalBytes = 0;
            if (raw && raw.byteLength) filter.write(raw);
          }
        } catch (e) {
          try { filter.write(event.data); } catch (e2) {}
        }
      };

      filter.onerror = () => {
        try { filter.disconnect(); } catch (e) {}
        firefoxInterceptRequestIds.delete(details.requestId);
        requestIdToHookIdMap.delete(details.requestId);
      };

      filter.onstop = async () => {
        try {
          if (state.passThrough) {
            try { filter.close(); } catch (e) {}
            firefoxInterceptRequestIds.delete(details.requestId);
            requestIdToHookIdMap.delete(details.requestId);
            return;
          }
          const bytes = concatUint8Chunks(state.originalChunks, state.totalBytes);
          state.originalText = decodeBytesToText(bytes, state.charset);
          let shouldInterceptResponse = false;
          if (
            interceptModeEnabled &&
            hostMatchesRules(state.host, interceptHostRules) &&
            !isToolingInterceptBypassed(state.tabId, state.url)
          ) {
            const cached = firefoxInterceptTypesCache || {};
            if (shouldCaptureByFilter(state.url, state.resourceType, 'firefox_filter', cached.types || DEFAULT_CAPTURE_TYPES, cached.custom || [])) {
              shouldInterceptResponse = true;
            }
          }
            const recordId = state.hookRecordId || ('ff_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8));
            state.recordId = recordId;
            if (typeof HawkEyeStorage !== 'undefined' && HawkEyeStorage.addRequest) {
              let oldReq = null;
              if (typeof HawkEyeStorage.getRequest === 'function') {
                try { oldReq = await HawkEyeStorage.getRequest(recordId); } catch (e) {}
              }
              await HawkEyeStorage.addRequest({
              id: recordId,
              url: state.url,
              method: state.method,
              requestHeaders: (oldReq && oldReq.requestHeaders && oldReq.requestHeaders.length > 0)
                ? oldReq.requestHeaders
                : ((p && p.requestHeaders) || []),
              requestBody: (oldReq && oldReq.requestBody)
                ? oldReq.requestBody
                : requestBodyToText((p && p.requestBody) || null),
              responseHeaders: state.responseHeaders,
              responseBody: state.originalText,
              statusCode: state.statusCode,
              tabId: state.tabId,
              detailsType: (oldReq && oldReq.detailsType) || ((p && p.type) ? p.type : details.type || ''),
              resourceType: state.resourceType,
              channelType: oldReq && oldReq.channelType ? oldReq.channelType : 'firefox_filter',
              mimeType: state.mimeType,
              host: state.host,
              durationMs: oldReq && oldReq.timestamp ? Math.max(0, Date.now() - Number(oldReq.timestamp || Date.now())) : 0,
              sizeBytes: bytes.byteLength,
              viewport: '',
              sensitiveHits: detectSensitiveHits({
                url: state.url,
                requestHeaders: (oldReq && oldReq.requestHeaders && oldReq.requestHeaders.length > 0)
                  ? oldReq.requestHeaders
                  : ((p && p.requestHeaders) || []),
                requestBody: (oldReq && oldReq.requestBody)
                  ? oldReq.requestBody
                  : requestBodyToText((p && p.requestBody) || null),
                responseHeaders: state.responseHeaders,
                responseBody: state.originalText,
              }),
            });
          }
          if (shouldInterceptResponse) {
            firefoxFilterByRecordId.set(recordId, state);
            interceptQueue.push(recordId);
            onRecordAdded(recordId, state.host);
          } else {
            onRecordAdded(recordId, state.host);
            try {
              const raw = concatUint8Chunks(state.originalChunks, state.totalBytes);
              if (raw && raw.byteLength) filter.write(raw);
              filter.close();
            } catch (e) {}
            firefoxInterceptRequestIds.delete(details.requestId);
            requestIdToHookIdMap.delete(details.requestId);
          }
        } catch (e) {
          // 失败时放过原始响应，避免页面卡住
          try {
            const raw = concatUint8Chunks(state.originalChunks, state.totalBytes);
            if (raw && raw.byteLength) state.filter.write(raw);
            state.filter.close();
          } catch (e2) {}
          firefoxInterceptRequestIds.delete(details.requestId);
          requestIdToHookIdMap.delete(details.requestId);
        }
      };
      return {};
    },
    { urls: ['<all_urls>'] },
    ['blocking', 'responseHeaders']
  );
} catch (e) {}

function refreshFirefoxInterceptTypesCache() {
  try {
    if (typeof getInterceptTypes !== 'function') return;
    getInterceptTypes().then((it) => {
      firefoxInterceptTypesCache = { types: (it && it.types) || firefoxInterceptTypesCache.types, custom: (it && it.custom) || [] };
    }).catch(() => {});
  } catch (e) {}
}

async function continueAllFirefoxPendingIntercepts() {
  if (!hx0FirefoxCaptureRuntime) return 0;
  let count = 0;
  try {
    const reqIds = Array.from(firefoxPendingRequestByRecordId.keys());
    for (const rid of reqIds) {
      try {
        if (await finalizeFirefoxRequestIntercept(rid, 'continue', null)) count++;
      } catch (e) {}
    }
    const filterIds = Array.from(firefoxFilterByRecordId.keys());
    for (const rid of filterIds) {
      try {
        if (finalizeFirefoxFilterIntercept(rid, 'continue', null)) count++;
      } catch (e) {}
    }
  } catch (e) {}
  return count;
}

function registerFirefoxCompatWebRequestLayer() {
  if (!hx0FirefoxCaptureRuntime) return;
  refreshFirefoxInterceptTypesCache();
}

if (hx0FirefoxCaptureRuntime) {
  try { registerFirefoxCompatWebRequestLayer(); } catch (e) {}
}
