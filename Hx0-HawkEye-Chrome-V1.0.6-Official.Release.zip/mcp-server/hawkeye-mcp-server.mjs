#!/usr/bin/env node
/**
 * Hx0 HawkEye MCP Server v1.0.6
 *
 * Zero-dependency local bridge:
 *   Any MCP host --stdio / Streamable HTTP / legacy SSE--> this process
 *   this process --WebSocket on 127.0.0.1--> Hx0 HawkEye extension
 *
 * stdout is reserved for JSON-RPC. Diagnostics are written to stderr.
 */
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import http from 'node:http';
import path from 'node:path';
import process from 'node:process';
import readline from 'node:readline';

const SERVER_NAME = 'hx0-hawkeye-mcp';
const SERVER_VERSION = '1.0.7';
const DEFAULT_WS_PORT = 19016;
const WS_PATH = '/hx0-mcp';
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const TOOL_TIMEOUT_MS = 35_000;

function stderr(message) {
  process.stderr.write('[Hx0 MCP] ' + String(message || '') + '\n');
}

function execNativeInput(file, args) {
  return new Promise((resolve, reject) => {
    execFile(file, args, { timeout: 8_000, windowsHide: true }, (error, stdout, stderrText) => {
      if (error) {
        const detail = String(stderrText || error.message || error).trim();
        reject(new Error(detail || 'Native input command failed'));
      } else resolve(String(stdout || '').trim());
    });
  });
}

function normalizeNativeKeyRequest(request) {
  const row = request && typeof request === 'object' ? request : {};
  const raw = String(row.key || '').trim();
  if (!raw || raw.length > 80) throw new Error('Invalid native key');
  const parts = raw === '+' ? ['+'] : raw.split('+').map((item) => item.trim()).filter(Boolean);
  let key = parts.pop() || raw;
  const modifiers = {
    shift: row.shiftKey === true,
    control: row.ctrlKey === true || row.controlKey === true,
    alt: row.altKey === true,
    meta: row.metaKey === true,
  };
  for (const part of parts) {
    const lower = part.toLowerCase();
    if (lower === 'shift') modifiers.shift = true;
    else if (lower === 'ctrl' || lower === 'control') modifiers.control = true;
    else if (lower === 'alt' || lower === 'option') modifiers.alt = true;
    else if (lower === 'meta' || lower === 'cmd' || lower === 'command') modifiers.meta = true;
  }
  const aliases = { esc: 'Escape', return: 'Enter', spacebar: 'Space', del: 'Delete', ins: 'Insert', left: 'ArrowLeft', right: 'ArrowRight', up: 'ArrowUp', down: 'ArrowDown' };
  const lower = key.toLowerCase();
  if (aliases[lower]) key = aliases[lower];
  else if (/^f(?:[1-9]|1[0-2])$/i.test(key)) key = key.toUpperCase();
  else if (/^arrow(left|right|up|down)$/i.test(key)) key = 'Arrow' + key.slice(5, 6).toUpperCase() + key.slice(6).toLowerCase();
  if (key.length === 1 && /[A-Z]/.test(key)) modifiers.shift = true;
  return { key, modifiers };
}

async function dispatchMacNativeInput(request) {
  if (request.kind === 'mouse') {
    const x = Math.round(Number(request.x));
    const y = Math.round(Number(request.y));
    if (!Number.isFinite(x) || !Number.isFinite(y) || Math.abs(x) > 100_000 || Math.abs(y) > 100_000) throw new Error('Invalid native mouse coordinates');
    await execNativeInput('/usr/bin/osascript', ['-e', 'tell application "System Events" to click at {' + x + ', ' + y + '}']);
    return { ok: true, backend: 'macos_system_events', kind: 'mouse', action: 'click', x, y };
  }
  const normalized = normalizeNativeKeyRequest(request);
  const keyCodes = { Enter: 36, Tab: 48, Space: 49, Backspace: 51, Escape: 53, Meta: 55, Shift: 56, Alt: 58, Control: 59, F1: 122, F2: 120, F3: 99, F4: 118, F5: 96, F6: 97, F7: 98, F8: 100, F9: 101, F10: 109, F11: 103, F12: 111, Home: 115, PageUp: 116, Delete: 117, End: 119, PageDown: 121, ArrowLeft: 123, ArrowRight: 124, ArrowDown: 125, ArrowUp: 126 };
  const modifierNames = [];
  if (normalized.modifiers.shift) modifierNames.push('shift down');
  if (normalized.modifiers.control) modifierNames.push('control down');
  if (normalized.modifiers.alt) modifierNames.push('option down');
  if (normalized.modifiers.meta) modifierNames.push('command down');
  const usingClause = modifierNames.length ? ' using {' + modifierNames.join(', ') + '}' : '';
  let action;
  if (Object.prototype.hasOwnProperty.call(keyCodes, normalized.key)) action = 'key code ' + keyCodes[normalized.key] + usingClause;
  else if (normalized.key.length === 1) action = 'keystroke ' + JSON.stringify(normalized.key.toLowerCase()) + usingClause;
  else throw new Error('Unsupported native key on macOS: ' + normalized.key);
  await execNativeInput('/usr/bin/osascript', ['-e', 'tell application "System Events" to ' + action]);
  return { ok: true, backend: 'macos_system_events', kind: 'key', key: normalized.key, modifiers: normalized.modifiers };
}

async function dispatchLinuxNativeInput(request) {
  if (request.kind === 'mouse') {
    const x = Math.round(Number(request.x));
    const y = Math.round(Number(request.y));
    if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('Invalid native mouse coordinates');
    await execNativeInput('xdotool', ['mousemove', '--sync', String(x), String(y), 'click', '1']);
    return { ok: true, backend: 'linux_xdotool', kind: 'mouse', action: 'click', x, y };
  }
  const normalized = normalizeNativeKeyRequest(request);
  const aliases = { Enter: 'Return', Space: 'space', Backspace: 'BackSpace', Escape: 'Escape', ArrowLeft: 'Left', ArrowRight: 'Right', ArrowUp: 'Up', ArrowDown: 'Down', PageUp: 'Prior', PageDown: 'Next', Meta: 'Super_L', Control: 'Control_L', Alt: 'Alt_L', Shift: 'Shift_L' };
  const parts = [];
  if (normalized.modifiers.control) parts.push('ctrl');
  if (normalized.modifiers.alt) parts.push('alt');
  if (normalized.modifiers.shift) parts.push('shift');
  if (normalized.modifiers.meta) parts.push('super');
  parts.push(aliases[normalized.key] || normalized.key);
  await execNativeInput('xdotool', ['key', '--clearmodifiers', parts.join('+')]);
  return { ok: true, backend: 'linux_xdotool', kind: 'key', key: normalized.key, modifiers: normalized.modifiers };
}

async function dispatchWindowsNativeInput(request) {
  const powershell = process.env.SystemRoot ? path.join(process.env.SystemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe') : 'powershell.exe';
  if (request.kind === 'mouse') {
    const x = Math.round(Number(request.x));
    const y = Math.round(Number(request.y));
    if (!Number.isFinite(x) || !Number.isFinite(y)) throw new Error('Invalid native mouse coordinates');
    const script = 'Add-Type -TypeDefinition \"using System; using System.Runtime.InteropServices; public static class Hx0Input { [DllImport(\\\"user32.dll\\\")] public static extern bool SetCursorPos(int X,int Y); [DllImport(\\\"user32.dll\\\")] public static extern void mouse_event(uint f,uint dx,uint dy,uint data,UIntPtr extra); }\"; [Hx0Input]::SetCursorPos(' + x + ',' + y + ') | Out-Null; [Hx0Input]::mouse_event(2,0,0,0,[UIntPtr]::Zero); [Hx0Input]::mouse_event(4,0,0,0,[UIntPtr]::Zero)';
    await execNativeInput(powershell, ['-NoProfile', '-NonInteractive', '-Command', script]);
    return { ok: true, backend: 'windows_sendinput', kind: 'mouse', action: 'click', x, y };
  }
  const normalized = normalizeNativeKeyRequest(request);
  const specials = { Enter: '{ENTER}', Tab: '{TAB}', Space: ' ', Backspace: '{BACKSPACE}', Escape: '{ESC}', Delete: '{DELETE}', Insert: '{INSERT}', Home: '{HOME}', End: '{END}', PageUp: '{PGUP}', PageDown: '{PGDN}', ArrowLeft: '{LEFT}', ArrowRight: '{RIGHT}', ArrowUp: '{UP}', ArrowDown: '{DOWN}', F1: '{F1}', F2: '{F2}', F3: '{F3}', F4: '{F4}', F5: '{F5}', F6: '{F6}', F7: '{F7}', F8: '{F8}', F9: '{F9}', F10: '{F10}', F11: '{F11}', F12: '{F12}' };
  let sendKey = specials[normalized.key] || (normalized.key.length === 1 ? normalized.key.toLowerCase().replace(/[+^%~(){}\[\]]/g, '{$&}') : '');
  if (!sendKey) throw new Error('Unsupported native key on Windows: ' + normalized.key);
  if (normalized.modifiers.shift) sendKey = '+' + sendKey;
  if (normalized.modifiers.control) sendKey = '^' + sendKey;
  if (normalized.modifiers.alt) sendKey = '%' + sendKey;
  const escaped = sendKey.replace(/'/g, "''");
  await execNativeInput(powershell, ['-NoProfile', '-NonInteractive', '-Command', "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.SendKeys]::SendWait('" + escaped + "')"]);
  return { ok: true, backend: 'windows_sendkeys', kind: 'key', key: normalized.key, modifiers: normalized.modifiers };
}

async function dispatchNativeInputRequest(request) {
  const row = request && typeof request === 'object' ? request : {};
  if (row.kind !== 'key' && row.kind !== 'mouse') throw new Error('Unsupported native input request');
  if (process.platform === 'darwin') return dispatchMacNativeInput(row);
  if (process.platform === 'win32') return dispatchWindowsNativeInput(row);
  if (process.platform === 'linux') return dispatchLinuxNativeInput(row);
  throw new Error('Native input is unsupported on ' + process.platform);
}

async function completeNativeInput(tool, preparedInput, result) {
  const request = result && result.nativeInputRequest;
  if (!request) {
    const pendingMode = String(result && (result.inputMode || result.input_mode) || '').toLowerCase();
    if (pendingMode === 'native_pending') {
      return Object.assign({}, result, {
        ok: false,
        error: 'Firefox native input relay did not receive nativeInputRequest. Update and restart the HawkEye MCP server; native_pending is an internal extension/server handshake state.',
        category: 'native_input_protocol_mismatch',
        hint: 'Replace the MCP server file with the one bundled in the same HawkEye release, then restart the MCP host.',
      });
    }
    return result;
  }
  try {
    const nativeInput = await dispatchNativeInputRequest(request);
    await new Promise((resolve) => setTimeout(resolve, 160));
    const finalized = await callExtension('browser_native_input_finalize', {
      tabId: result.tabId,
      frameId: result.frameId,
      probeToken: result.probeToken,
    });
    const merged = Object.assign({}, result, finalized || {}, {
      ok: true,
      inputMode: request.kind === 'key' ? 'native_os_key' : 'native_os_mouse',
      input_mode: request.kind === 'key' ? 'native_os_key' : 'native_os_mouse',
      inputModes: [request.kind === 'key' ? 'native_os_key' : 'native_os_mouse'],
      nativeInput,
    });
    delete merged.nativeInputRequest;
    delete merged.probeToken;
    return merged;
  } catch (error) {
    const mode = String(preparedInput && (preparedInput.inputMode || preparedInput.input_mode || preparedInput.clickMode || preparedInput.click_mode) || 'auto').toLowerCase();
    if (mode === 'auto') {
      const fallbackInput = Object.assign({}, preparedInput, tool === 'browser_click' ? { clickMode: 'js' } : { inputMode: 'js' });
      const fallback = await callExtension(tool, fallbackInput);
      return Object.assign({}, fallback || {}, { nativeFallbackUsed: true, nativeInputError: String(error && error.message || error), inputModes: ['native_failed', fallback && (fallback.input_mode || fallback.inputMode) || 'js'] });
    }
    return Object.assign({}, result, { ok: false, error: 'Native input failed: ' + String(error && error.message || error), category: 'trusted_input_unavailable', hint: process.platform === 'darwin' ? 'Allow Accessibility control for the terminal/MCP host in macOS Privacy & Security, then retry.' : 'Install/enable the local OS input backend, then retry.' });
  }
}

function parsePort() {
  const argv = process.argv.slice(2);
  const at = argv.findIndex((item) => item === '--ws-port' || item === '--port');
  const raw = at >= 0 ? argv[at + 1] : process.env.HX0_MCP_WS_PORT;
  const port = Number(raw || DEFAULT_WS_PORT);
  if (!Number.isInteger(port) || port < 1024 || port > 65535) {
    throw new Error('Invalid WebSocket port: ' + String(raw));
  }
  return port;
}

if (process.argv.includes('--version')) {
  process.stdout.write(SERVER_VERSION + '\n');
  process.exit(0);
}
if (process.argv.includes('--help')) {
  process.stdout.write([
    'Hx0 HawkEye MCP Server v' + SERVER_VERSION,
    '',
    'Usage: node hawkeye-mcp-server.mjs [--port 19016]',
    'Environment: HX0_MCP_WS_PORT=19016',
    '',
    'VIP / Pro access is required to enable the HawkEye extension bridge and call tools.',
    'Enable “HawkEye Browser Automation MCP” in the HawkEye extension popup, then add this file',
    'as a stdio MCP server in any MCP client. HTTP-capable hosts may connect to:',
    '  Streamable HTTP: http://127.0.0.1:19016/mcp',
    '  Legacy SSE:      http://127.0.0.1:19016/sse',
    '',
  ].join('\n'));
  process.exit(0);
}

const TOOLS = [
  {
    name: 'browser_navigate',
    description: 'Navigate the HawkEye-connected real browser tab to an HTTP(S) URL and return a fresh accessibility snapshot. Private/lab hosts (RFC1918, localhost, link-local) with a self-signed or otherwise untrusted certificate are auto-proceeded past the browser interstitial (Chrome: Advanced → Proceed; Firefox: Accept the Risk). The address bar may still show Not secure; use browser_security for diagnosis. Public-site certificate warnings are not auto-proceeded.',
    inputSchema: { type: 'object', properties: { url: { type: 'string', description: 'Absolute or current-page-relative HTTP(S) URL.' } }, required: ['url'], additionalProperties: false },
  },
  {
    name: 'browser_search',
    description: 'Search the public web with multiple engines and/or query variants, deduplicate URLs, fuse rankings, expose engine telemetry, and optionally fetch top evidence. This is HawkEye-owned and has no external search-service dependency.',
    inputSchema: { type: 'object', properties: { query: { type: 'string' }, queries: { type: 'array', maxItems: 6, items: { type: 'string' } }, engine: { type: 'string', enum: ['auto', 'bing', 'baidu', 'google', 'duckduckgo'] }, engines: { type: 'array', maxItems: 4, items: { type: 'string', enum: ['auto', 'bing', 'baidu', 'google', 'duckduckgo'] } }, maxResults: { type: 'integer', minimum: 1, maximum: 25 }, maxFetches: { type: 'integer', minimum: 0, maximum: 5 }, includeDomains: { type: 'array', maxItems: 12, items: { type: 'string' } }, excludeDomains: { type: 'array', maxItems: 12, items: { type: 'string' } }, timeRange: { type: 'string', enum: ['day', 'week', 'month', 'year'] }, exactMatch: { type: 'boolean' }, cacheMode: { type: 'string', enum: ['prefer', 'refresh', 'only'] }, context_budget_chars: { type: 'integer', minimum: 12000, maximum: 300000 } }, additionalProperties: false },
  },
  {
    name: 'browser_fetch',
    description: 'Open a public HTTP(S) URL in an isolated temporary browser tab (session cookies apply), extract rendered readable text, detect challenge pages, cache bounded evidence, and record the exchange into HawkEye capture history unless capture=false. Private/local addresses are rejected.',
    inputSchema: { type: 'object', properties: { url: { type: 'string' }, maxChars: { type: 'integer', minimum: 4000, maximum: 160000 }, cacheMode: { type: 'string', enum: ['prefer', 'refresh', 'only'] }, capture: { type: 'boolean', description: 'Record the fetched page into HawkEye capture history. Defaults to true.' }, timeoutMs: { type: 'integer', minimum: 500, maximum: 20000 }, context_budget_chars: { type: 'integer', minimum: 12000, maximum: 300000 } }, required: ['url'], additionalProperties: false },
  },
  {
    name: 'browser_research',
    description: 'Run a bounded autonomous public-web evidence-gathering loop: derive query variants, search multiple engines, fuse rankings, fetch top pages, and return citation-ready sources plus gaps and transparent degradation telemetry.',
    inputSchema: { type: 'object', properties: { prompt: { type: 'string' }, queries: { type: 'array', maxItems: 6, items: { type: 'string' } }, depth: { type: 'string', enum: ['quick', 'standard', 'deep'] }, engines: { type: 'array', maxItems: 4, items: { type: 'string', enum: ['auto', 'bing', 'baidu', 'google', 'duckduckgo'] } }, maxPages: { type: 'integer', minimum: 1, maximum: 15 }, maxTimeMs: { type: 'integer', minimum: 10000, maximum: 180000 }, includeDomains: { type: 'array', maxItems: 12, items: { type: 'string' } }, excludeDomains: { type: 'array', maxItems: 12, items: { type: 'string' } }, timeRange: { type: 'string', enum: ['day', 'week', 'month', 'year'] }, cacheMode: { type: 'string', enum: ['prefer', 'refresh', 'only'] }, context_budget_chars: { type: 'integer', minimum: 16000, maximum: 300000 } }, required: ['prompt'], additionalProperties: false },
  },
  {
    name: 'browser_go_back',
    description: 'Go back in the connected browser tab and return a fresh accessibility snapshot.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'browser_go_forward',
    description: 'Go forward in the connected browser tab and return a fresh accessibility snapshot.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'browser_snapshot',
    description: 'Return a compact, viewport-first accessibility snapshot with stable frame refs and stable data ids. Heavy pages default to in-viewport nodes (max ~200). Pass viewport_only=false or raise max_elements for the full tree. Compact mode notes folded interactive items. Decorative images and HawkEye/Monica/Coco overlays are omitted by default.',
    inputSchema: { type: 'object', properties: { boxes: { type: 'boolean', description: 'Include viewport-relative x/y/width/height for exposed elements.' }, compact: { type: 'boolean', description: 'Deduplicate semantic rows and omit decorative noise. Defaults to true.' }, expand_selector: { type: 'string', description: 'Keep matching nodes even when compact folding would hide them.' }, diff: { type: 'boolean', description: 'Return only new/changed/removed semantic nodes since the previous snapshot for this focus scope.' }, exclude_img: { type: 'boolean', description: 'Exclude all standalone images; decorative images are already excluded in compact mode.' }, focus: { type: 'string', description: 'Scope to main, list, or a CSS selector.' }, max_elements: { type: 'integer', minimum: 20, maximum: 1000 }, viewport_only: { type: 'boolean', description: 'Only include nodes that intersect the current viewport. Defaults to true.' }, exclude_selectors: { type: 'array', items: { type: 'string' }, maxItems: 20 }, include_overlays: { type: 'boolean' }, context_budget_chars: { type: 'integer', minimum: 12000, maximum: 400000, description: 'Maximum snapshot characters returned in this context chunk.' }, cursor: { type: 'integer', minimum: 0, description: 'Character cursor returned by a previous snapshot chunk.' } }, additionalProperties: false },
  },
  {
    name: 'browser_find',
    description: 'Search the compact accessibility snapshot for plain text or a regular expression and return only bounded surrounding snippets. Prefer this over a full snapshot when locating content on a large page.',
    inputSchema: { type: 'object', properties: { text: { type: 'string' }, regex: { type: 'string' }, flags: { type: 'string' }, before: { type: 'integer', minimum: 0, maximum: 8 }, after: { type: 'integer', minimum: 0, maximum: 8 }, limit: { type: 'integer', minimum: 1, maximum: 100 }, compact: { type: 'boolean' }, focus: { type: 'string' }, max_elements: { type: 'integer', minimum: 20, maximum: 1000 } }, additionalProperties: false },
  },
  {
    name: 'browser_security',
    description: 'Read structured TLS/certificate evidence for the connected page and diagnose hostname mismatch, expiry, not-yet-valid, untrusted-chain, or browser TLS errors. Auto-proceeding a private/lab interstitial does not make the certificate trusted. Never infer certificate validity from a screenshot or page body. If evidence is absent, refresh=true performs one diagnostic reload.',
    inputSchema: { type: 'object', properties: { refresh: { type: 'boolean' }, timeoutMs: { type: 'integer', minimum: 500, maximum: 20000 } }, additionalProperties: false },
  },
  {
    name: 'browser_click',
    description: 'Click the smallest real interactive target (inner a/button, not a wrapping card). Auto prefers focused CDP pointer input so activation-gated APIs work, then safely falls back to JS when trusted input is unavailable. trusted never silently degrades to synthetic JS. Returns eventEvidence/userActivationObserved when measurable. Prefer a ref/stableId. For dropdown values use browser_select_option.',
    inputSchema: { type: 'object', properties: { element: { type: 'string', description: 'Human-readable description only; it is not exact-match text.' }, text: { type: 'string', description: 'Authoritative accessible text. Required when exact=true.' }, exact: { type: 'boolean', description: 'Exact accessible-name match; folds whitespace only and is case-sensitive by default.' }, caseSensitive: { type: 'boolean', description: 'Override text case sensitivity.' }, clickMode: { type: 'string', enum: ['auto', 'js', 'trusted'], description: 'auto prefers real CDP pointer input and falls back to JS; js forces synthetic DOM activation; trusted requires CDP pointer input and fails closed.' }, stableId: { type: 'string', description: 'Stable business id returned by browser_snapshot, such as data-challenge-id:42 or route-id:42.' }, ref: { type: 'string', description: 'Element ref from browser_snapshot.' }, selector: { type: 'string', description: 'Optional CSS selector fallback.' } }, additionalProperties: false },
  },
  {
    name: 'browser_hover',
    description: 'Hover an element in the connected page. Prefer a ref returned by browser_snapshot.',
    inputSchema: { type: 'object', properties: { element: { type: 'string' }, ref: { type: 'string' }, selector: { type: 'string' } }, additionalProperties: false },
  },
  {
    name: 'browser_type',
    description: 'Type text into a native input, textarea, contenteditable, or same-origin rich-text editor. A visible form label may be used as element. Replaces existing value unless clear=false; submit=true submits its form.',
    inputSchema: { type: 'object', properties: { element: { type: 'string' }, ref: { type: 'string' }, selector: { type: 'string' }, text: { type: 'string' }, clear: { type: 'boolean' }, submit: { type: 'boolean' } }, required: ['text'], additionalProperties: false },
  },
  {
    name: 'browser_select_option',
    description: 'Select options from native or custom dropdowns (including Ant Design/Element-style controls). Pass the visible field label in element and the desired visible option in value; this performs the trusted open-and-option click sequence.',
    inputSchema: { type: 'object', properties: { element: { type: 'string' }, ref: { type: 'string' }, selector: { type: 'string' }, values: { type: 'array', items: { type: 'string' } }, value: { type: 'string' } }, additionalProperties: false },
  },
  {
    name: 'browser_press_key',
    description: 'Send a key such as f, Enter, Tab, Escape, ArrowDown, or Ctrl+L to the focused or referenced element. Auto prefers focused CDP Input.dispatchKeyEvent so activation-gated APIs work; trusted fails closed instead of silently emitting synthetic DOM events.',
    inputSchema: { type: 'object', properties: { key: { type: 'string' }, element: { type: 'string' }, ref: { type: 'string' }, selector: { type: 'string' }, inputMode: { type: 'string', enum: ['auto', 'js', 'trusted'], description: 'auto prefers CDP and falls back to JS; trusted requires CDP; js sends synthetic DOM KeyboardEvents.' }, shiftKey: { type: 'boolean' }, ctrlKey: { type: 'boolean' }, altKey: { type: 'boolean' }, metaKey: { type: 'boolean' } }, required: ['key'], additionalProperties: false },
  },
  {
    name: 'browser_wait',
    description: 'Wait briefly for dynamic UI. Defaults to 0.3s and does not return a page snapshot unless includeSnapshot is true.',
    inputSchema: { type: 'object', properties: { time: { type: 'number', minimum: 0, maximum: 10, description: 'Seconds to wait. Defaults to 0.3.' }, includeSnapshot: { type: 'boolean', description: 'If true, return a fresh accessibility snapshot after waiting.' } }, additionalProperties: false },
  },
  {
    name: 'browser_get_console_logs',
    description: 'Read console messages and unhandled page errors captured since HawkEye connected.',
    inputSchema: { type: 'object', properties: { limit: { type: 'integer', minimum: 1, maximum: 300 } }, additionalProperties: false },
  },
  {
    name: 'browser_screenshot',
    description: 'Capture the viewport, full page, or one element and return the image together with a compact accessibility note by default, so both vision and text-only models can reason about the same state.',
    inputSchema: { type: 'object', properties: { fullPage: { type: 'boolean', description: 'Capture the complete scrollable page. Cannot be combined with an element target.' }, element: { type: 'string', description: 'Human-readable element description.' }, ref: { type: 'string', description: 'Element ref from browser_snapshot.' }, selector: { type: 'string', description: 'CSS selector fallback for an element screenshot.' }, target: { type: 'string', description: 'Playwright-compatible shorthand: an element ref or CSS selector.' }, type: { type: 'string', enum: ['png', 'jpeg'] }, quality: { type: 'integer', minimum: 1, maximum: 100, description: 'JPEG quality. Ignored for PNG.' }, includeSnapshot: { type: 'boolean', description: 'Include a compact accessibility note. Defaults to true.' }, compact: { type: 'boolean' }, exclude_img: { type: 'boolean' }, focus: { type: 'string' }, max_elements: { type: 'integer', minimum: 20, maximum: 1000 }, save_to_file: { type: 'boolean', description: 'Also save the screenshot to a local image file. Defaults to false; the image response is always preserved.' }, file_path: { type: 'string', maxLength: 4096, description: 'Optional destination. Absolute paths are used directly; relative paths are resolved below HAWKEYE_SCREENSHOT_DIR or $CWD/screenshots.' }, overwrite: { type: 'boolean', description: 'Allow replacement of an existing screenshot file. Defaults to false.' } }, additionalProperties: false },
  },
  {
    name: 'browser_captcha_assist',
    description: 'Detect and assist with a custom or first-party CAPTCHA on the connected page. For login image codes (checkCode next to 验证码), always use this tool: action=analyze returns an upscaled crop. Read only the large dark foreground characters; ignore colorful lines and faint background glyphs. Do not hawkeye_evaluate pixel dumps, download the img src, or click the image (click refreshes). Then action=solve with authorized=true and answer. For sliders, analyze may open a gated dialog and return suggestedOffsetRatio; solve drags with a paced pointer and waits for READY/granted. Do not immediately re-solve while verification.phase is busy or the copy still says SCANNING. reCAPTCHA, hCaptcha, Turnstile, Arkose, GeeTest, Tencent and Alibaba anti-bot challenges are reported as manual_required and are never automated.',
    inputSchema: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['analyze', 'solve'], description: 'Defaults to analyze.' },
        authorized: { type: 'boolean', description: 'Required for solve. Confirms the caller is authorized to automate this first-party challenge.' },
        challengeType: { type: 'string', enum: ['auto', 'image_text', 'copy_text', 'math', 'slider'], description: 'Optional detection preference.' },
        candidateIndex: { type: 'integer', minimum: 0, maximum: 11, description: 'Choose one candidate returned by analyze. Defaults to 0.' },
        answer: { type: 'string', description: 'Recognized image/copy text or calculated arithmetic answer.' },
        offsetRatio: { type: 'number', minimum: 0, maximum: 1, description: 'Slider target center measured from the track left edge (0) to right edge (1).' },
        submit: { type: 'boolean', description: 'Submit the containing form after filling. Defaults to false.' },
        type: { type: 'string', enum: ['png', 'jpeg'] },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'browser_resize',
    description: 'Resize the page CSS viewport for responsive-layout testing. Prefers Chrome DevTools Emulation.setDeviceMetricsOverride; falls back to resizing the browser window. Returns requested vs applied viewport. Use action=reset after testing.',
    inputSchema: { type: 'object', properties: { width: { type: 'integer', minimum: 320, maximum: 3840 }, height: { type: 'integer', minimum: 240, maximum: 2160 }, action: { type: 'string', enum: ['resize', 'reset'] }, reset: { type: 'boolean', description: 'Equivalent to action=reset.' } }, additionalProperties: false },
  },
  {
    name: 'browser_tabs',
    description: 'List, create, bind/select, or close real browser tabs. Selecting a tab updates the HawkEye MCP binding for subsequent calls.',
    inputSchema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'new', 'select', 'close'] }, tabId: { type: 'integer' }, url: { type: 'string' }, active: { type: 'boolean' }, bind: { type: 'boolean' }, allWindows: { type: 'boolean' } }, additionalProperties: false },
  },
  {
    name: 'browser_reload',
    description: 'Reload the connected tab, optionally bypassing cache, then return a fresh accessibility snapshot.',
    inputSchema: { type: 'object', properties: { bypassCache: { type: 'boolean' }, timeoutMs: { type: 'integer', minimum: 500, maximum: 20000 } }, additionalProperties: false },
  },
  {
    name: 'browser_wait_for',
    description: 'Wait until page readiness, URL text, visible/hidden element state, or page text matches, then return a snapshot.',
    inputSchema: { type: 'object', properties: { ref: { type: 'string' }, selector: { type: 'string' }, element: { type: 'string' }, text: { type: 'string' }, urlContains: { type: 'string' }, state: { type: 'string', enum: ['visible', 'hidden', 'attached', 'detached'] }, timeoutMs: { type: 'integer', minimum: 100, maximum: 30000 }, pollMs: { type: 'integer', minimum: 50, maximum: 2000 } }, additionalProperties: false },
  },
  {
    name: 'browser_fill_form',
    description: 'Fill multiple native or custom form controls in one operation using refs, selectors, or visible labels. Supports custom dropdowns and contenteditable/rich-text fields; optionally submits the containing form.',
    inputSchema: { type: 'object', properties: { fields: { type: 'array', minItems: 1, maxItems: 50, items: { type: 'object', properties: { ref: { type: 'string' }, selector: { type: 'string' }, element: { type: 'string' }, name: { type: 'string' }, label: { type: 'string' }, value: {}, values: { type: 'array', items: {} } }, additionalProperties: false } }, submit: { type: 'boolean' } }, required: ['fields'], additionalProperties: false },
  },
  {
    name: 'browser_exam_questions',
    description: 'Extract structured choice, true/false, and text questions from the page or nested iframes, with frame-scoped refs.',
    inputSchema: { type: 'object', properties: { context_budget_chars: { type: 'integer', minimum: 12000, maximum: 400000 }, cursor: { type: 'integer', minimum: 0 } }, additionalProperties: false },
  },
  {
    name: 'browser_answer_questions',
    description: 'Fill a bounded set of exam/form answers without submitting. Match questions by index or text.',
    inputSchema: { type: 'object', properties: { answers: { type: 'array', minItems: 1, maxItems: 100, items: { type: 'object', properties: { index: { type: 'integer' }, number: { type: 'integer' }, question: { type: 'string' }, answer: {}, answers: { type: 'array', items: {} }, value: {} }, additionalProperties: false } } }, required: ['answers'], additionalProperties: false },
  },
  {
    name: 'browser_handle_dialog',
    description: 'Configure the next JavaScript confirm/prompt answer and read recently captured alert/confirm/prompt evidence without blocking browser automation.',
    inputSchema: { type: 'object', properties: { action: { type: 'string', enum: ['accept', 'dismiss'] }, promptText: { type: 'string' }, clear: { type: 'boolean' }, limit: { type: 'integer', minimum: 1, maximum: 50 } }, additionalProperties: false },
  },
  {
    name: 'browser_file_upload',
    description: 'Attach local files to a file input. The local MCP Server reads the paths and securely transfers bounded file bytes to the connected page.',
    inputSchema: { type: 'object', properties: { ref: { type: 'string' }, selector: { type: 'string' }, element: { type: 'string' }, path: { type: 'string' }, paths: { type: 'array', minItems: 1, maxItems: 10, items: { type: 'string' } } }, additionalProperties: false },
  },
  {
    name: 'browser_download_file',
    description: 'Discover downloadable resources on the connected page or add an explicit HTTP(S) file URL to the browser native download queue. Supports video, audio, documents, spreadsheets, PDFs, archives, installers, and other browser-downloadable files. action=discover never starts a download; follow it with action=download. A download is successful only when nativeDownloadStarted=true and downloadId are returned.',
    inputSchema: {
      type: 'object',
      properties: {
        action: { type: 'string', enum: ['discover', 'download'] },
        url: { type: 'string', description: 'Absolute or current-page-relative HTTP(S) file URL. Omit to discover from page media and file links.' },
        filename: { type: 'string', description: 'Optional basename for the downloaded file.' },
        resourceHint: { type: 'string', description: 'Filename, extension, label, or media hint used to rank discovered resources.' },
        saveAs: { type: 'boolean', description: 'Show the browser Save As dialog. Defaults to false.' },
        conflictAction: { type: 'string', enum: ['uniquify', 'overwrite', 'prompt'] },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'browser_drag',
    description: 'Drag one element and drop it onto another using a trusted pointer path plus HTML5 drag-and-drop events. Use for ordinary sliders, sortable lists, kanban cards, and canvas drag interactions. Use browser_captcha_assist for an authorized first-party CAPTCHA. Prefer refs from browser_snapshot for both the start and end targets; both must be in the same frame.',
    inputSchema: { type: 'object', properties: { startElement: { type: 'string', description: 'Human-readable description of the element to drag.' }, startRef: { type: 'string', description: 'Start element ref from browser_snapshot.' }, startSelector: { type: 'string', description: 'Optional CSS selector for the start element.' }, endElement: { type: 'string', description: 'Human-readable description of the drop target.' }, endRef: { type: 'string', description: 'End element ref from browser_snapshot.' }, endSelector: { type: 'string', description: 'Optional CSS selector for the drop target.' } }, additionalProperties: false },
  },
  {
    name: 'browser_scroll',
    description: 'Scroll the page or a scrollable container to trigger lazy-loading and reach off-screen content, then return a fresh accessibility snapshot. Provide direction plus optional amount, or to=top/bottom, or a ref/selector/element to scroll that target into view.',
    inputSchema: { type: 'object', properties: { direction: { type: 'string', enum: ['up', 'down', 'left', 'right'], description: 'Scroll direction. Defaults to down.' }, amount: { type: 'integer', minimum: 1, maximum: 40000, description: 'Pixels to scroll. Defaults to ~85% of the viewport height.' }, to: { type: 'string', enum: ['top', 'bottom'], description: 'Jump to the top or bottom instead of scrolling by an amount.' }, element: { type: 'string', description: 'Human-readable description of an element or container to scroll into view or scroll within.' }, ref: { type: 'string', description: 'Element ref from browser_snapshot.' }, selector: { type: 'string', description: 'Optional CSS selector fallback.' } }, additionalProperties: false },
  },
  {
    name: 'browser_read_text',
    description: 'Extract cleaned, human-readable text from the connected page or a specific container, including open Shadow DOM and injectable iframes. Use to read long articles, documentation, or page source that the accessibility snapshot condenses. Large results use cursor-based context chunks.',
    inputSchema: { type: 'object', properties: { selector: { type: 'string', description: 'Optional CSS selector to scope extraction; defaults to the main/article/body content.' }, maxChars: { type: 'integer', minimum: 1000, maximum: 400000, description: 'Maximum characters to extract from the page.' }, context_budget_chars: { type: 'integer', minimum: 12000, maximum: 400000, description: 'Maximum text characters returned in this context chunk.' }, cursor: { type: 'integer', minimum: 0, description: 'Character cursor returned by a previous chunk.' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_capture_start',
    description: 'Enable HawkEye browser traffic capture.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'hawkeye_capture_stop',
    description: 'Disable HawkEye browser traffic capture.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'hawkeye_capture_state',
    description: 'Return HawkEye capture state and MCP-bound tab information.',
    inputSchema: { type: 'object', properties: {}, additionalProperties: false },
  },
  {
    name: 'hawkeye_capture_history',
    description: 'Read redacted HTTP/WebSocket record summaries captured by HawkEye. With no host, results stay scoped to the MCP-bound tab and its current host. Pass targetHost to search captured history across tabs for that host. Use hawkeye_request_get for selected details.',
    inputSchema: {
      type: 'object',
      properties: {
        targetHost: { type: 'string' }, search: { type: 'string' }, method: { type: 'string' },
        resourceType: { type: 'string' }, channelType: { type: 'string' },
        limit: { type: 'integer', minimum: 1, maximum: 200 },
      },
      additionalProperties: false,
    },
  },
  {
    name: 'hawkeye_capture_inspect',
    description: 'Inspect one HawkEye capture record for sensitive-data, dark-link, and flag evidence.',
    inputSchema: { type: 'object', properties: { recordId: { type: 'string' }, id: { type: 'string' }, url: { type: 'string' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_request_get',
    description: 'Read selected portions of one locally captured request/response, keeping large or sensitive bodies out of context unless explicitly requested.',
    inputSchema: { type: 'object', properties: { recordId: { type: 'string' }, id: { type: 'string' }, url: { type: 'string' }, parts: { type: 'array', items: { type: 'string', enum: ['summary', 'request_headers', 'request_body', 'response_headers', 'response_body', 'raw_request', 'raw_response'] } }, maxChars: { type: 'integer', minimum: 1000, maximum: 100000 } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_request_replay',
    description: 'Send a direct HTTP request or replay a captured request inside the explicitly authorized HawkEye testing scope. For ordinary API calls provide url plus query/params, headers, json or form; rawRequest/recordId remain available for exact replays.',
    inputSchema: { type: 'object', properties: { recordId: { type: 'string' }, rawRequest: { type: 'string' }, url: { type: 'string' }, method: { type: 'string' }, headers: { type: 'object' }, query: { type: 'object', additionalProperties: true }, params: { type: 'object', additionalProperties: true }, body: { type: 'string' }, json: {}, form: { type: 'object', additionalProperties: true }, timeoutMs: { type: 'integer', minimum: 100, maximum: 60000 } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_request_mutate',
    description: 'Generate bounded request variants without sending them. Use a captured record or raw request plus a parameter and up to eight values.',
    inputSchema: { type: 'object', properties: { recordId: { type: 'string' }, rawRequest: { type: 'string' }, url: { type: 'string' }, parameter: { type: 'string' }, variants: { type: 'array', minItems: 1, maxItems: 8, items: {} } }, required: ['parameter', 'variants'], additionalProperties: false },
  },
  {
    name: 'hawkeye_fuzz_run',
    description: 'Run a bounded security-test fuzz job (maximum 12 requests) only for a host explicitly authorized in HawkEye scope with fuzzing enabled.',
    inputSchema: { type: 'object', properties: { recordId: { type: 'string' }, rawRequest: { type: 'string' }, url: { type: 'string' }, parameter: { type: 'string' }, variants: { type: 'array', maxItems: 6, items: {} }, payloads: { type: 'array', maxItems: 12, items: { type: 'string' } }, executeLimit: { type: 'integer', minimum: 1, maximum: 12 }, stopOnFlags: { type: 'boolean' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_response_compare',
    description: 'Compare two captured or inline responses by status, headers, size, timing, and bounded text similarity.',
    inputSchema: { type: 'object', properties: { leftRecordId: { type: 'string' }, rightRecordId: { type: 'string' }, left: { type: 'object' }, right: { type: 'object' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_scope',
    description: 'Read or configure the explicit authorized-host scope and active-testing/fuzzing switches used by HawkEye security-test request tools.',
    inputSchema: { type: 'object', properties: { action: { type: 'string', enum: ['get', 'set', 'add', 'remove', 'clear'] }, host: { type: 'string' }, hosts: { type: 'array', maxItems: 100, items: { type: 'string' } }, includeSubdomains: { type: 'boolean' }, activeTestingEnabled: { type: 'boolean' }, fuzzingEnabled: { type: 'boolean' }, acknowledgeAuthorization: { type: 'boolean', description: 'Confirms written authorization for hosts being added.' }, confirm: { type: 'boolean' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_findings',
    description: 'Create, update, list, get, or remove locally stored security findings with evidence and remediation guidance.',
    inputSchema: { type: 'object', properties: { action: { type: 'string', enum: ['list', 'get', 'upsert', 'create', 'update', 'remove', 'clear'] }, id: { type: 'string' }, severity: { type: 'string' }, status: { type: 'string' }, host: { type: 'string' }, limit: { type: 'integer', minimum: 1, maximum: 200 }, finding: { type: 'object' }, confirm: { type: 'boolean' } }, additionalProperties: true },
  },
  {
    name: 'hawkeye_codec',
    description: "HawkEye's built-in encode/decode, hashing and crypto helpers. Runs a single transform locally in the extension (no network). Encoders: base64, base64url, url, hex, unicode, html, base32, rot13 (encode/decode). Digests: md5, sha1, sha256, sha512, sm3, hmacsha256 (needs key). Utilities: jwt_parse, timestamp_convert, json_pretty/compact/escape/unescape. Use action=auto_probe to auto-detect and decode suspicious base64/url tokens (e.g. flags) inside arbitrary text.",
    inputSchema: { type: 'object', properties: { action: { type: 'string', description: 'Transform to run, e.g. base64_decode, base64url_encode, url_encode, hex_decode, md5, sha256, sm3, hmacsha256, jwt_parse, timestamp_convert, json_pretty, auto_probe.' }, text: { type: 'string', description: 'The input string to transform.' }, key: { type: 'string', description: 'Secret key for keyed transforms such as hmacsha256.' } }, required: ['action'], additionalProperties: true },
  },
  {
    name: 'hawkeye_script_list',
    description: 'List the user script plugins installed in the HawkEye extension (Tampermonkey-style), including each script id, name, enabled state, match rules, and how well it matches a given page URL or host. Use this before hawkeye_script_run to pick the right script.',
    inputSchema: { type: 'object', properties: { url: { type: 'string', description: 'Optional page URL to rank scripts by match relevance.' }, host: { type: 'string', description: 'Optional host to rank scripts by match relevance.' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_script_run',
    description: 'Execute an installed HawkEye user script plugin on the bound page. Identify the script by scriptId, or by name/query for a best-effort match. The script runs in its configured world (page or isolated) exactly as a manual run would.',
    inputSchema: { type: 'object', properties: { scriptId: { type: 'string', description: 'The exact script id from hawkeye_script_list.' }, name: { type: 'string', description: 'Script name or search query when the id is unknown.' }, tabId: { type: 'integer', description: 'Optional tab id; defaults to the MCP-bound tab.' } }, additionalProperties: false },
  },
  {
    name: 'hawkeye_evaluate',
    description: "Run arbitrary JavaScript in the bound page MAIN world via chrome.debugger Runtime.evaluate (DevTools-level, not subject to page script-src or the MV3 extension CSP that blocks eval/new Function). returnByValue serializes the result; console and exceptions are captured. Do not switch to USER_SCRIPT to bypass CSP: that isolated world cannot see page variables and still uses eval. Failures are classified as csp_blocked, script_syntax_error, script_runtime_error, timeout, permission_denied, debugger_unavailable, or injection_no_result.",
    inputSchema: { type: 'object', properties: { code: { type: 'string', description: 'JavaScript to execute. Runtime completion values are captured for return, bare expressions, async/await, DOM nodes, arrays, objects, and functions.' }, world: { type: 'string', enum: ['MAIN', 'USER_SCRIPT', 'ISOLATED'], description: 'Execution world. MAIN (default) sees page variables/libraries; USER_SCRIPT is CSP-exempt but isolated; ISOLATED is the content-script world.' }, tabId: { type: 'integer', description: 'Optional tab id; defaults to the MCP-bound tab.' }, maxLength: { type: 'integer', minimum: 256, maximum: 1000000, description: 'Max characters of the serialized result/preview. Defaults to 500000.' }, timeoutMs: { type: 'integer', minimum: 250, maximum: 60000 } }, required: ['code'], additionalProperties: true },
  },
  {
    name: 'hawkeye_script_upsert',
    description: "Create or update a persistent HawkEye user script plugin (Tampermonkey-style). Provide the JavaScript in `code` (a full ==UserScript== metadata block is also accepted). Use this to author a reusable script that solves a page problem, then run it with hawkeye_script_run. Prefer hawkeye_evaluate for one-off computations; use this when the logic should persist and re-run on matching pages.",
    inputSchema: { type: 'object', properties: { code: { type: 'string', description: 'The script source. May include a Tampermonkey ==UserScript== header.' }, scriptId: { type: 'string', description: 'Existing script id to update; omit to create a new script.' }, name: { type: 'string' }, description: { type: 'string' }, matchMode: { type: 'string', enum: ['manual', 'auto'], description: 'manual = only runs when explicitly invoked; auto = runs on matching pages.' }, matches: { type: 'array', items: { type: 'string' }, description: 'URL match patterns for auto mode, e.g. https://example.com/*.' }, runAt: { type: 'string', enum: ['document_start', 'document_end', 'document_idle'] }, world: { type: 'string', enum: ['USER_SCRIPT', 'MAIN'] }, enabled: { type: 'boolean' } }, required: ['code'], additionalProperties: true },
  },
  {
    name: 'hawkeye_sensitive_scan',
    description: "Scan for exposed sensitive information (API keys, tokens, credentials, phone/ID numbers, private endpoints, etc.) using HawkEye's sensitive-info detector. Provide inline `html`/`text`/`responseBody` to scan arbitrary content, a `recordId` to scan one captured request/response, or a `targetHost` (optionally with `recordIds`) to batch-scan captured history. Read-only local analysis. Requires the sensitive detector to be enabled in the extension.",
    inputSchema: { type: 'object', properties: { text: { type: 'string' }, html: { type: 'string' }, responseBody: { type: 'string' }, requestBody: { type: 'string' }, recordId: { type: 'string', description: 'Captured record id to scan.' }, recordIds: { type: 'array', items: { type: 'string' } }, targetHost: { type: 'string', description: 'Host to batch-scan from captured history.' }, limit: { type: 'integer', minimum: 1, maximum: 200 } }, additionalProperties: true },
  },
  {
    name: 'hawkeye_darklink_scan',
    description: "Detect dark links / malicious or hidden links, black-hat SEO injection, hidden iframes and suspicious outbound targets on a page using HawkEye's threat analyzer. With no content it scans the live bound-tab DOM (use_dom). You can also pass inline `html`, a `recordId`, or a `targetHost`/`recordIds` to batch-scan captured history. scan_mode selects auto, worker_analyzer (offline HTML), or dom_injected. Read-only. Requires dark-link detection to be enabled in the extension.",
    inputSchema: { type: 'object', properties: { html: { type: 'string' }, url: { type: 'string' }, recordId: { type: 'string' }, recordIds: { type: 'array', items: { type: 'string' } }, targetHost: { type: 'string' }, use_dom: { type: 'boolean', description: 'Scan the live tab DOM (default true when no content is provided).' }, scan_mode: { type: 'string', enum: ['auto', 'worker_analyzer', 'dom_injected'], description: 'Force analyzer mode. auto picks DOM injection when a tab is available.' }, mode: { type: 'string', enum: ['auto', 'worker_analyzer', 'dom_injected'] }, batch: { type: 'boolean' }, limit: { type: 'integer', minimum: 1, maximum: 200 }, tabId: { type: 'integer' } }, additionalProperties: true },
  },
  {
    name: 'hawkeye_intercept',
    description: "Control HawkEye's request interceptor to pause, inspect, modify, forward or drop live traffic on the bound tab (like Burp intercept). Actions: enable (start pausing requests), status (enabled/queued count), queue (list paused requests with id/url/method/headers/body and stage=request|response), release (forward a paused request by id, optionally modifying it via payload{url,method,requestHeaders,requestBody,statusCode,responseHeaders,responseBody}), drop (abort a paused request by id), release_all (forward everything), disable (stop and release all). Typical loop: enable -> trigger the request in the page -> queue -> release/drop by id -> disable. Always disable when finished so the page is not left hanging.",
    inputSchema: { type: 'object', properties: { action: { type: 'string', enum: ['enable', 'disable', 'status', 'queue', 'release', 'drop', 'release_all'] }, id: { type: 'string', description: 'Paused record id from action=queue (for release/drop).' }, payload: { type: 'object', description: 'Optional modifications when releasing: url, method, requestHeaders, requestBody, statusCode, responseHeaders, responseBody.', additionalProperties: true }, limit: { type: 'integer', minimum: 1, maximum: 100 } }, required: ['action'], additionalProperties: true },
  },
];

for (const tool of TOOLS) {
  const readOnly = new Set(['browser_snapshot', 'browser_find', 'browser_search', 'browser_fetch', 'browser_research', 'browser_exam_questions', 'browser_read_text', 'browser_get_console_logs', 'browser_screenshot', 'browser_wait', 'browser_wait_for', 'hawkeye_capture_state', 'hawkeye_capture_history', 'hawkeye_capture_inspect', 'hawkeye_request_get', 'hawkeye_request_mutate', 'hawkeye_response_compare', 'hawkeye_codec', 'hawkeye_script_list', 'hawkeye_sensitive_scan', 'hawkeye_darklink_scan']).has(tool.name);
  const destructive = tool.name === 'browser_tabs' || tool.name === 'hawkeye_scope' || tool.name === 'hawkeye_findings' || tool.name === 'hawkeye_intercept';
  const openWorld = /^browser_|request_replay$|fuzz_run$/.test(tool.name.replace(/^hawkeye_/, ''));
  tool.annotations = { title: tool.name.replace(/_/g, ' '), readOnlyHint: readOnly, destructiveHint: destructive, idempotentHint: readOnly || tool.name === 'browser_reload', openWorldHint: openWorld };
}

function encodeFrame(text, opcode = 0x1) {
  const payload = Buffer.from(String(text), 'utf8');
  let head;
  if (payload.length < 126) {
    head = Buffer.from([0x80 | opcode, payload.length]);
  } else if (payload.length <= 0xffff) {
    head = Buffer.alloc(4);
    head[0] = 0x80 | opcode;
    head[1] = 126;
    head.writeUInt16BE(payload.length, 2);
  } else {
    head = Buffer.alloc(10);
    head[0] = 0x80 | opcode;
    head[1] = 127;
    head.writeBigUInt64BE(BigInt(payload.length), 2);
  }
  return Buffer.concat([head, payload]);
}

class BrowserSocket {
  constructor(socket, onMessage, onClose) {
    this.socket = socket;
    this.onMessage = onMessage;
    this.onClose = onClose;
    this.buffer = Buffer.alloc(0);
    this.fragments = [];
    this.fragmentOpcode = 0;
    this.closed = false;
    socket.on('data', (chunk) => this.feed(chunk));
    socket.on('close', () => this.finish());
    socket.on('end', () => this.finish());
    socket.on('error', () => this.finish());
  }

  sendJson(value) {
    if (this.closed || !this.socket.writable) return false;
    try {
      this.socket.write(encodeFrame(JSON.stringify(value)));
      return true;
    } catch {
      return false;
    }
  }

  close() {
    if (this.closed) return;
    try { this.socket.write(encodeFrame('', 0x8)); } catch {}
    try { this.socket.end(); } catch {}
    this.finish();
  }

  finish() {
    if (this.closed) return;
    this.closed = true;
    try { this.onClose(this); } catch {}
  }

  feed(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 2) {
      const first = this.buffer[0];
      const second = this.buffer[1];
      const fin = !!(first & 0x80);
      const opcode = first & 0x0f;
      const masked = !!(second & 0x80);
      let length = second & 0x7f;
      let offset = 2;
      if (length === 126) {
        if (this.buffer.length < 4) return;
        length = this.buffer.readUInt16BE(2);
        offset = 4;
      } else if (length === 127) {
        if (this.buffer.length < 10) return;
        const large = this.buffer.readBigUInt64BE(2);
        if (large > BigInt(32 * 1024 * 1024)) { this.close(); return; }
        length = Number(large);
        offset = 10;
      }
      const maskOffset = masked ? 4 : 0;
      if (this.buffer.length < offset + maskOffset + length) return;
      let payload = this.buffer.subarray(offset + maskOffset, offset + maskOffset + length);
      if (masked) {
        const mask = this.buffer.subarray(offset, offset + 4);
        const decoded = Buffer.alloc(length);
        for (let i = 0; i < length; i += 1) decoded[i] = payload[i] ^ mask[i % 4];
        payload = decoded;
      }
      this.buffer = this.buffer.subarray(offset + maskOffset + length);
      if (opcode === 0x8) { this.close(); return; }
      if (opcode === 0x9) {
        try { this.socket.write(Buffer.concat([Buffer.from([0x8a, payload.length]), payload])); } catch {}
        continue;
      }
      if (opcode === 0xa) continue;
      if (opcode === 0x1 || opcode === 0x2) {
        this.fragments = [payload];
        this.fragmentOpcode = opcode;
      } else if (opcode === 0x0 && this.fragments.length) {
        this.fragments.push(payload);
      } else {
        continue;
      }
      if (!fin) continue;
      const complete = Buffer.concat(this.fragments);
      const messageOpcode = this.fragmentOpcode;
      this.fragments = [];
      this.fragmentOpcode = 0;
      if (messageOpcode !== 0x1) continue;
      try { this.onMessage(complete.toString('utf8'), this); } catch {}
    }
  }
}

const pendingCalls = new Map();
let extensionSocket = null;
let extensionReady = false;
let extensionInfo = null;
let callSequence = 0;

function rejectPending(reason) {
  for (const [, row] of pendingCalls) {
    clearTimeout(row.timer);
    row.reject(new Error(reason));
  }
  pendingCalls.clear();
}

function handleExtensionMessage(raw, client) {
  let message;
  try { message = JSON.parse(raw); } catch { return; }
  if (!message || typeof message !== 'object') return;
  if (message.type === 'hx0_mcp_hello') {
    extensionSocket = client;
    extensionReady = true;
    extensionInfo = {
      version: String(message.extensionVersion || ''),
      browser: String(message.browser || ''),
      tabId: message.tabId == null ? null : Number(message.tabId),
    };
    client.sendJson({ type: 'hx0_mcp_ready', protocol: 'hx0-mcp-v1', serverVersion: SERVER_VERSION });
    stderr('HawkEye extension connected' + (extensionInfo.tabId != null ? ' (tab ' + extensionInfo.tabId + ')' : ''));
    return;
  }
  if (message.type === 'hx0_mcp_pong') return;
  if (message.type === 'hx0_mcp_tool_result' && message.id) {
    const row = pendingCalls.get(String(message.id));
    if (!row) return;
    pendingCalls.delete(String(message.id));
    clearTimeout(row.timer);
    if (message.ok === false) row.reject(new Error(String(message.error || 'HawkEye tool failed')));
    else row.resolve(message.result);
  }
}

function hx0ToolTimeoutMs(tool) {
  if (tool === 'browser_research') return 190_000;
  if (tool === 'browser_search' || tool === 'browser_fetch' || tool === 'browser_captcha_assist' || tool === 'hawkeye_fuzz_run') return 120_000;
  if (
    tool === 'browser_snapshot' || tool === 'browser_navigate' || tool === 'browser_reload' ||
    tool === 'browser_read_text' || tool === 'browser_find' || tool === 'browser_screenshot' ||
    tool === 'browser_go_back' || tool === 'browser_go_forward' || tool === 'browser_wait_for' ||
    tool === 'browser_scroll'
  ) return 90_000;
  return TOOL_TIMEOUT_MS;
}

function slimCaptchaAssistResult(result) {
  const row = result && typeof result === 'object' ? result : {};
  const slimCandidate = (item) => {
    const cand = item && typeof item === 'object' ? item : {};
    return {
      type: cand.type || '',
      score: cand.score,
      provider: cand.provider || '',
      expression: cand.expression || '',
      answer: cand.answer || '',
      containerRef: cand.containerRef || '',
      imageRef: cand.imageRef || '',
      inputRef: cand.inputRef || '',
      handleRef: cand.handleRef || '',
      trackRef: cand.trackRef || '',
      text: String(cand.text || '').slice(0, 280),
    };
  };
  const candidates = Array.isArray(row.candidates) ? row.candidates.slice(0, 4).map(slimCandidate) : [];
  return {
    ok: row.ok !== false,
    value: row.value == null ? null : row.value,
    error: row.error || null,
    hint: row.hint || null,
    action: row.action,
    tabId: row.tabId,
    url: row.url,
    detected: row.detected === true,
    manual_required: !!row.manual_required,
    suggestedOffsetRatio: row.suggestedOffsetRatio,
    expectedLength: row.expectedLength,
    recognitionHint: row.recognitionHint,
    clickRefreshes: row.clickRefreshes,
    scope: row.scope,
    width: row.width,
    height: row.height,
    imageSource: row.imageSource,
    challenge: slimCandidate(row.challenge),
    candidates,
    count: Number(row.count != null ? row.count : candidates.length) || candidates.length,
  };
}

function callExtension(tool, input) {
  if (!extensionSocket || extensionSocket.closed || !extensionReady) {
    return Promise.reject(new Error('HawkEye extension is not connected. Enable “HawkEye Browser Automation MCP” in the extension popup.'));
  }
  const id = 'mcp_' + Date.now().toString(36) + '_' + (++callSequence).toString(36);
  return new Promise((resolve, reject) => {
    const timeoutMs = hx0ToolTimeoutMs(tool);
    const timer = setTimeout(() => {
      pendingCalls.delete(id);
      reject(new Error('HawkEye extension did not respond within ' + Math.round(timeoutMs / 1000) + ' seconds'));
    }, timeoutMs);
    pendingCalls.set(id, { resolve, reject, timer });
    const sent = extensionSocket.sendJson({ type: 'hx0_mcp_tool_call', id, tool, input: input && typeof input === 'object' ? input : {} });
    if (!sent) {
      clearTimeout(timer);
      pendingCalls.delete(id);
      reject(new Error('Failed to send command to HawkEye extension'));
    }
  });
}

function mimeTypeForFile(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  return ({ '.txt': 'text/plain', '.json': 'application/json', '.html': 'text/html', '.htm': 'text/html', '.csv': 'text/csv', '.xml': 'application/xml', '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.zip': 'application/zip' })[ext] || 'application/octet-stream';
}

const SCREENSHOT_ILLEGAL_FILE_CHARS = /[\u0000-\u001f<>:"|?*]/g;
const SCREENSHOT_WINDOWS_RESERVED_NAME = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;

function sanitizeScreenshotPathPart(value, fallback = 'capture') {
  let safe = String(value == null ? '' : value)
    .replace(SCREENSHOT_ILLEGAL_FILE_CHARS, '_')
    .replace(/[\/\\]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_+/g, '_')
    .replace(/^\.+|\.+$/g, '')
    .slice(0, 96);
  if (!safe || safe === '.' || safe === '..' || SCREENSHOT_WINDOWS_RESERVED_NAME.test(safe)) safe = fallback;
  return safe;
}

function screenshotFileExtension(mimeType, requestedType) {
  const mime = String(mimeType || '').toLowerCase();
  const type = String(requestedType || '').toLowerCase();
  return mime === 'image/jpeg' || type === 'jpeg' || type === 'jpg' ? '.jpg' : '.png';
}

function screenshotFileTimestamp(date = new Date()) {
  const two = (value) => String(value).padStart(2, '0');
  const three = (value) => String(value).padStart(3, '0');
  return String(date.getFullYear()) + two(date.getMonth() + 1) + two(date.getDate()) + '_'
    + two(date.getHours()) + two(date.getMinutes()) + two(date.getSeconds()) + '_' + three(date.getMilliseconds());
}

function withScreenshotImageExtension(filePath, extension) {
  const parsed = path.parse(filePath);
  const current = parsed.ext.toLowerCase();
  if (!current) return filePath + extension;
  if (current === extension || (extension === '.jpg' && current === '.jpeg')) return filePath;
  return path.join(parsed.dir, parsed.name + extension);
}

function relativeScreenshotFilePath(rawPath) {
  const parts = String(rawPath || '').replace(/\\/g, '/').split('/').filter((part) => part && part !== '.')
    .map((part) => part === '..' ? '_parent_' : sanitizeScreenshotPathPart(part, 'capture'));
  return parts.length ? path.join(...parts) : '';
}

function defaultScreenshotDirectory() {
  const configured = String(process.env.HAWKEYE_SCREENSHOT_DIR || '').trim();
  return path.resolve(configured || path.join(process.cwd(), 'screenshots'));
}

function resolveScreenshotFilePath(requestInput = {}, result = {}, mimeType = 'image/png', now = new Date()) {
  const extension = screenshotFileExtension(mimeType, requestInput.type);
  const requestedPath = String(requestInput.file_path || '').trim();
  let targetPath;
  if (requestedPath && path.isAbsolute(requestedPath)) {
    const resolved = path.resolve(requestedPath);
    targetPath = path.join(path.dirname(resolved), sanitizeScreenshotPathPart(path.basename(resolved), 'screenshot' + extension));
  } else {
    const root = defaultScreenshotDirectory();
    const relative = relativeScreenshotFilePath(requestedPath);
    if (relative) {
      targetPath = path.resolve(root, relative);
      const boundary = path.relative(root, targetPath);
      if (boundary.startsWith('..' + path.sep) || boundary === '..' || path.isAbsolute(boundary)) {
        throw new Error('relative screenshot path escapes the configured screenshot directory');
      }
    } else {
      const label = sanitizeScreenshotPathPart(result.scope || requestInput.element || requestInput.ref || requestInput.selector || requestInput.target || 'viewport', 'viewport');
      targetPath = path.join(root, 'screenshot_' + screenshotFileTimestamp(now) + '_' + label + extension);
    }
  }
  return path.resolve(withScreenshotImageExtension(targetPath, extension));
}

async function saveScreenshotImage({ base64, mimeType, requestInput = {}, result = {} } = {}) {
  let targetPath = null;
  try {
    targetPath = resolveScreenshotFilePath(requestInput, result, mimeType);
    const imageBuffer = Buffer.from(String(base64 || ''), 'base64');
    if (!imageBuffer.length) throw new Error('decoded screenshot is empty');
    await fs.mkdir(path.dirname(targetPath), { recursive: true });
    await fs.writeFile(targetPath, imageBuffer, { flag: requestInput.overwrite === true ? 'w' : 'wx' });
    return { saved_to: targetPath, file_path: targetPath, file_bytes: imageBuffer.length, save_error: null };
  } catch (error) {
    return { saved_to: null, file_path: targetPath, file_bytes: 0, save_error: String(error && error.message || error || 'unknown file save error') };
  }
}

async function prepareToolInput(tool, rawInput) {
  const input = rawInput && typeof rawInput === 'object' ? { ...rawInput } : {};
  if (tool !== 'browser_file_upload') return input;
  const filePaths = (Array.isArray(input.paths) ? input.paths : [input.path]).map((item) => String(item || '').trim()).filter(Boolean).slice(0, 10);
  if (!filePaths.length) throw new Error('browser_file_upload requires path or paths');
  const files = [];
  let totalBytes = 0;
  for (const filePath of filePaths) {
    const stat = await fs.stat(filePath);
    if (!stat.isFile()) throw new Error('Upload path is not a regular file: ' + filePath);
    if (stat.size > 5 * 1024 * 1024) throw new Error('Each upload file must be 5 MB or smaller: ' + filePath);
    totalBytes += stat.size;
    if (totalBytes > 10 * 1024 * 1024) throw new Error('Combined upload size must be 10 MB or smaller');
    const data = await fs.readFile(filePath);
    files.push({ name: path.basename(filePath), mimeType: mimeTypeForFile(filePath), lastModified: Math.round(stat.mtimeMs), base64: data.toString('base64') });
  }
  delete input.path;
  delete input.paths;
  input.files = files;
  return input;
}

function extensionToolInput(tool, preparedInput) {
  if (tool !== 'browser_screenshot') return preparedInput;
  const input = { ...preparedInput };
  delete input.save_to_file;
  delete input.file_path;
  delete input.overwrite;
  return input;
}

function compactValue(value, depth = 0, limits = {}) {
  const maxString = Math.max(2000, Number(limits.maxString) || 48_000);
  const maxArray = Math.max(20, Number(limits.maxArray) || 400);
  if (depth > 7) return '[depth truncated]';
  if (typeof value === 'string') {
    if (value.length <= maxString) return value;
    const marker = '\n[adaptive context: kept ' + maxString + ' of ' + value.length + ' chars; middle omitted]\n';
    const room = Math.max(200, maxString - marker.length);
    const head = Math.floor(room * 0.68);
    return value.slice(0, head) + marker + value.slice(value.length - (room - head));
  }
  if (value == null || typeof value === 'number' || typeof value === 'boolean') return value;
  if (Array.isArray(value)) {
    const rows = value.length <= maxArray
      ? value
      : value.slice(0, Math.floor(maxArray * 0.7)).concat([{ _context_notice: 'kept ' + maxArray + ' of ' + value.length + ' items' }], value.slice(-Math.ceil(maxArray * 0.3)));
    return rows.map((item) => compactValue(item, depth + 1, limits));
  }
  if (typeof value === 'object') {
    const out = {};
    for (const key of Object.keys(value).slice(0, 240)) {
      if (key === 'dataUrl' || key === 'imageDataUrl') continue;
      out[key] = compactValue(value[key], depth + 1, limits);
    }
    return out;
  }
  return String(value);
}

function contextChunk(text, input, defaultBudget) {
  const source = String(text == null ? '' : text);
  const budget = Math.max(12_000, Math.min(400_000, Number(input && input.context_budget_chars) || defaultBudget || 160_000));
  const cursor = Math.max(0, Math.min(source.length, Number(input && input.cursor) || 0));
  const end = Math.min(source.length, cursor + budget);
  const nextCursor = end < source.length ? end : null;
  const prefix = cursor > 0 ? '[context chunk starts at character ' + cursor + ']\n' : '';
  const suffix = nextCursor != null ? '\n[more context available: call again with cursor=' + nextCursor + ']' : '';
  return { text: prefix + source.slice(cursor, end) + suffix, cursor, nextCursor, totalChars: source.length, budgetChars: budget, complete: nextCursor == null };
}

async function toolResultContent(tool, result, requestInput) {
  result = result && typeof result === 'object' ? { ...result } : { ok: true, value: result == null ? null : result };
  result.ok = result.ok !== false;
  if (!Object.prototype.hasOwnProperty.call(result, 'value')) result.value = null;
  result.error = result.ok ? null : String(result.error || 'tool failed');
  if (!Object.prototype.hasOwnProperty.call(result, 'hint')) result.hint = null;
  if (tool === 'browser_captcha_assist') result = Object.assign({}, result, slimCaptchaAssistResult(result));
  if ((tool === 'browser_screenshot' || tool === 'browser_captcha_assist') && result && typeof result.dataUrl === 'string') {
    const match = result.dataUrl.match(/^data:(image\/[^;]+);base64,(.+)$/s);
    if (match) {
      const saveResult = tool === 'browser_screenshot' && requestInput && requestInput.save_to_file === true
        ? await saveScreenshotImage({ base64: match[2], mimeType: match[1], requestInput, result })
        : null;
      const saveNote = !saveResult
        ? ''
        : saveResult.saved_to
          ? '\n已保存到: ' + saveResult.saved_to
          : '\n截图已生成但保存失败: ' + saveResult.save_error;
      const screenshotMetadata = { ok: result.ok !== false, value: null, error: result.error, hint: result.hint, url: result.url, scope: result.scope, fullPage: result.fullPage, element: result.element, mimeType: result.mimeType, bytes: result.bytes, width: result.width, height: result.height, sourceWidth: result.sourceWidth, sourceHeight: result.sourceHeight, scale: result.scale, accessibility: result.accessibility };
      return {
        content: [
          { type: 'image', data: match[2], mimeType: match[1] },
          { type: 'text', text: (tool === 'browser_captcha_assist' ? 'CAPTCHA assistance result' : 'Screenshot captured') + ' (' + String(result.scope || 'viewport') + (result.width && result.height ? ', ' + result.width + 'x' + result.height : '') + ') from ' + String(result.url || 'the connected tab') + (tool === 'browser_captcha_assist' ? '\n\n' + JSON.stringify(slimCaptchaAssistResult(result), null, 2) : (result.accessibilitySnapshot ? '\n\nAccessibility note:\n' + contextChunk(result.accessibilitySnapshot, requestInput, 80_000).text : '')) + saveNote },
        ],
        structuredContent: tool === 'browser_captcha_assist'
          ? slimCaptchaAssistResult(result)
          : compactValue(saveResult ? { ...screenshotMetadata, ...saveResult } : screenshotMetadata),
      };
    }
  }
  if (result && typeof result.snapshot === 'string' && result.snapshot.trim()) {
    const chunk = contextChunk(result.snapshot, requestInput, 160_000);
    const metadata = compactValue(Object.fromEntries(Object.entries(result).filter(([key]) => key !== 'snapshot')), 0, { maxString: 24_000, maxArray: 300 });
    const context = { cursor: chunk.cursor, next_cursor: chunk.nextCursor, total_chars: chunk.totalChars, budget_chars: chunk.budgetChars, complete: chunk.complete };
    return { content: [{ type: 'text', text: chunk.text }], structuredContent: { ...metadata, context } };
  }
  const budget = Math.max(12_000, Math.min(400_000, Number(requestInput && requestInput.context_budget_chars) || 120_000));
  const structuredContent = compactValue(result, 0, { maxString: Math.min(80_000, budget), maxArray: 500 });
  const serialized = JSON.stringify(structuredContent, null, 2);
  if (serialized.length <= budget) return { content: [{ type: 'text', text: serialized }], structuredContent };
  const chunk = contextChunk(serialized, requestInput, budget);
  const context = { cursor: chunk.cursor, next_cursor: chunk.nextCursor, total_chars: chunk.totalChars, budget_chars: chunk.budgetChars, complete: chunk.complete };
  return { content: [{ type: 'text', text: chunk.text }], structuredContent: { ok: result && result.ok !== false, value: null, error: result && result.ok === false ? String(result.error || 'tool failed') : null, hint: result && result.hint || null, context } };
}

function rpcResult(id, result) {
  return { jsonrpc: '2.0', id, result };
}

function rpcError(id, code, message, data) {
  const error = { code, message: String(message || 'Error') };
  if (data !== undefined) error.data = data;
  return { jsonrpc: '2.0', id: id == null ? null : id, error };
}

async function handleRpc(message) {
  if (!message || message.jsonrpc !== '2.0') return rpcError(null, -32600, 'Invalid Request');
  const id = message.id;
  const method = String(message.method || '');
  if (!Object.prototype.hasOwnProperty.call(message, 'id')) return null;
  try {
    if (method === 'initialize') {
      return rpcResult(id, {
        protocolVersion: String((message.params && message.params.protocolVersion) || '2025-06-18'),
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: SERVER_NAME, title: 'Hx0 HawkEye Browser Automation & Security Testing', version: SERVER_VERSION },
        instructions: 'Enable HawkEye Browser Automation MCP in the Hx0 HawkEye extension popup. Call browser_snapshot before interactions and use diff=true for incremental state; request boxes only for spatial reasoning. Prefer refs and stable business ids. For exact clicks put the accessible name in text (element is description-only). browser_click auto mode resolves the smallest real target and verifies route changes. Use browser_select_option for selects/comboboxes/custom dropdowns and never click a decorative arrow. For a custom first-party CAPTCHA, call browser_captcha_assist action=analyze and inspect its returned image; never hawkeye_evaluate or download the captcha img. Image codes: read the large dark characters only, then action=solve with authorized=true and answer. Sliders: confirm suggestedOffsetRatio then solve. Third-party anti-bot challenges always require manual completion. For public knowledge, use browser_search, browser_fetch, or browser_research. Active request replay and bounded fuzz testing require an explicitly authorized hawkeye_scope.',
      });
    }
    if (method === 'ping') {
      return rpcResult(id, {});
    }
    if (method === 'tools/list') {
      return rpcResult(id, { tools: TOOLS });
    }
    if (method === 'tools/call') {
      const params = message.params && typeof message.params === 'object' ? message.params : {};
      const name = String(params.name || '');
      if (!TOOLS.some((tool) => tool.name === name)) {
        return rpcError(id, -32602, 'Unknown tool: ' + name);
      }
      try {
        const preparedInput = await prepareToolInput(name, params.arguments || {});
        const bridgeInput = extensionToolInput(name, preparedInput);
        const initialResult = await callExtension(name, bridgeInput);
        const result = await completeNativeInput(name, bridgeInput, initialResult);
        return rpcResult(id, await toolResultContent(name, result, preparedInput));
      } catch (error) {
        const failed = { ok: false, value: null, error: String(error && error.message || error), hint: null };
        return rpcResult(id, { isError: true, ...await toolResultContent(name, failed, params.arguments || {}) });
      }
    }
    return rpcError(id, -32601, 'Method not found: ' + method);
  } catch (error) {
    return rpcError(id, -32603, String(error && error.message || error));
  }
}

const wsPort = parsePort();
const legacySseClients = new Map();

function requestOriginAllowed(request) {
  const origin = String(request.headers.origin || '');
  if (!origin) return true;
  try {
    const parsed = new URL(origin);
    return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && (parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost');
  } catch {
    return false;
  }
}

function extensionOriginAllowed(origin) {
  return String(origin || '').startsWith('chrome-extension://') || String(origin || '').startsWith('moz-extension://');
}

function loopbackCorsHeaders(request) {
  const origin = String(request.headers.origin || '');
  if (!extensionOriginAllowed(origin)) return {};
  return {
    'access-control-allow-origin': origin,
    'access-control-allow-methods': 'GET, OPTIONS',
    'access-control-allow-headers': 'content-type',
    'access-control-allow-private-network': 'true',
    vary: 'Origin',
  };
}

function readJsonBody(request, limitBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    request.on('data', (chunk) => {
      total += chunk.length;
      if (total > limitBytes) {
        reject(new Error('Request body too large'));
        request.destroy();
        return;
      }
      chunks.push(chunk);
    });
    request.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch { reject(new Error('Invalid JSON')); }
    });
    request.on('error', reject);
  });
}

function writeJson(res, status, value, extraHeaders) {
  const body = value == null ? '' : JSON.stringify(value);
  res.writeHead(status, Object.assign({
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
  }, extraHeaders || {}));
  res.end(body);
}

async function handleHttpRpc(request, res) {
  if (!requestOriginAllowed(request)) {
    writeJson(res, 403, rpcError(null, -32000, 'Cross-origin access denied'));
    return;
  }
  const contentType = String(request.headers['content-type'] || '').toLowerCase();
  if (!contentType.startsWith('application/json')) {
    writeJson(res, 415, rpcError(null, -32600, 'Content-Type must be application/json'));
    return;
  }
  let payload;
  try { payload = await readJsonBody(request); }
  catch (error) {
    writeJson(res, 400, rpcError(null, -32700, error.message));
    return;
  }
  if (Array.isArray(payload)) {
    const rows = (await Promise.all(payload.map((item) => handleRpc(item)))).filter(Boolean);
    if (!rows.length) res.writeHead(202, { 'cache-control': 'no-store' }).end();
    else writeJson(res, 200, rows, { 'mcp-protocol-version': '2025-06-18' });
    return;
  }
  const response = await handleRpc(payload);
  if (!response) res.writeHead(202, { 'cache-control': 'no-store' }).end();
  else writeJson(res, 200, response, { 'mcp-protocol-version': '2025-06-18' });
}

const httpServer = http.createServer((request, res) => {
  const url = new URL(String(request.url || '/'), 'http://127.0.0.1');
  if (request.method === 'OPTIONS' && url.pathname === '/health') {
    const origin = String(request.headers.origin || '');
    if (!extensionOriginAllowed(origin)) { res.writeHead(403).end(); return; }
    res.writeHead(204, loopbackCorsHeaders(request)).end();
    return;
  }
  if (request.method === 'POST' && url.pathname === '/mcp') {
    handleHttpRpc(request, res).catch((error) => writeJson(res, 500, rpcError(null, -32603, error.message)));
    return;
  }
  if (request.method === 'GET' && url.pathname === '/mcp') {
    if (!requestOriginAllowed(request)) { res.writeHead(403).end(); return; }
    res.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-store',
      connection: 'keep-alive',
    });
    res.write(': Hx0 HawkEye MCP event stream\n\n');
    const timer = setInterval(() => { try { res.write(': keepalive\n\n'); } catch {} }, 20_000);
    timer.unref();
    request.on('close', () => clearInterval(timer));
    return;
  }
  if (request.method === 'DELETE' && url.pathname === '/mcp') {
    res.writeHead(204, { 'cache-control': 'no-store' }).end();
    return;
  }
  if (request.method === 'GET' && url.pathname === '/sse') {
    if (!requestOriginAllowed(request)) { res.writeHead(403).end(); return; }
    const sessionId = crypto.randomBytes(18).toString('hex');
    res.writeHead(200, {
      'content-type': 'text/event-stream',
      'cache-control': 'no-store',
      connection: 'keep-alive',
    });
    legacySseClients.set(sessionId, res);
    res.write('event: endpoint\ndata: /messages?sessionId=' + sessionId + '\n\n');
    const timer = setInterval(() => { try { res.write(': keepalive\n\n'); } catch {} }, 20_000);
    timer.unref();
    request.on('close', () => { clearInterval(timer); legacySseClients.delete(sessionId); });
    return;
  }
  if (request.method === 'POST' && url.pathname === '/messages') {
    if (!requestOriginAllowed(request)) { res.writeHead(403).end(); return; }
    const stream = legacySseClients.get(String(url.searchParams.get('sessionId') || ''));
    if (!stream) { writeJson(res, 404, rpcError(null, -32001, 'Unknown SSE session')); return; }
    const contentType = String(request.headers['content-type'] || '').toLowerCase();
    if (!contentType.startsWith('application/json')) { writeJson(res, 415, rpcError(null, -32600, 'Content-Type must be application/json')); return; }
    readJsonBody(request).then(handleRpc).then((response) => {
      if (response) stream.write('event: message\ndata: ' + JSON.stringify(response) + '\n\n');
      res.writeHead(202, { 'cache-control': 'no-store' }).end();
    }).catch((error) => writeJson(res, 400, rpcError(null, -32700, error.message)));
    return;
  }
  if (request.method === 'GET' && url.pathname === '/health') {
    const origin = String(request.headers.origin || '');
    if (origin && !extensionOriginAllowed(origin) && !requestOriginAllowed(request)) { res.writeHead(403).end(); return; }
    writeJson(res, 200, { ok: true, name: SERVER_NAME, version: SERVER_VERSION, extensionConnected: extensionReady, extension: extensionInfo }, loopbackCorsHeaders(request));
    return;
  }
  res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
  res.end('Hx0 HawkEye MCP server\n');
});

httpServer.on('upgrade', (request, socket) => {
  const origin = String(request.headers.origin || '');
  const allowedOrigin = origin.startsWith('chrome-extension://') || origin.startsWith('moz-extension://') || (process.env.HX0_MCP_ALLOW_TEST_ORIGIN === '1' && origin === 'hx0-test://local');
  const url = new URL(String(request.url || '/'), 'http://127.0.0.1');
  const key = String(request.headers['sec-websocket-key'] || '');
  if (url.pathname !== WS_PATH || !allowedOrigin || !key || String(request.headers.upgrade || '').toLowerCase() !== 'websocket') {
    stderr('Rejected WebSocket bridge request (origin=' + (origin || 'missing') + ', path=' + url.pathname + ').');
    socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n');
    socket.destroy();
    return;
  }
  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write([
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    'Sec-WebSocket-Accept: ' + accept,
    '', '',
  ].join('\r\n'));
  if (extensionSocket && !extensionSocket.closed) extensionSocket.close();
  const client = new BrowserSocket(socket, handleExtensionMessage, (closed) => {
    if (extensionSocket === closed) {
      extensionSocket = null;
      extensionReady = false;
      extensionInfo = null;
      rejectPending('HawkEye extension disconnected');
      stderr('HawkEye extension disconnected');
    }
  });
  extensionSocket = client;
  extensionReady = false;
});

httpServer.on('error', (error) => {
  if (error && error.code === 'EADDRINUSE') {
    stderr('Port ' + wsPort + ' is already in use. Stop the other MCP process or set HX0_MCP_WS_PORT to another port in both the MCP client and HawkEye popup.');
  } else {
    stderr(error && error.stack || error);
  }
  process.exitCode = 2;
});

httpServer.listen(wsPort, '127.0.0.1', () => {
  stderr('WebSocket bridge listening on ws://127.0.0.1:' + wsPort + WS_PATH);
  stderr('Streamable HTTP endpoint: http://127.0.0.1:' + wsPort + '/mcp');
  stderr('Legacy SSE endpoint: http://127.0.0.1:' + wsPort + '/sse');
});

const keepAlive = setInterval(() => {
  if (extensionSocket && !extensionSocket.closed) extensionSocket.sendJson({ type: 'hx0_mcp_ping', at: Date.now() });
}, 20_000);
keepAlive.unref();

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity, terminal: false });
rl.on('line', (line) => {
  const text = String(line || '').trim();
  if (!text) return;
  let message;
  try { message = JSON.parse(text); }
  catch { process.stdout.write(JSON.stringify(rpcError(null, -32700, 'Parse error')) + '\n'); return; }
  Promise.resolve(handleRpc(message)).then((response) => {
    if (response) process.stdout.write(JSON.stringify(response) + '\n');
  }).catch((error) => stderr(error && error.stack || error));
});

function shutdown() {
  clearInterval(keepAlive);
  rejectPending('MCP server shutting down');
  if (extensionSocket) extensionSocket.close();
  for (const [, stream] of legacySseClients) {
    try { stream.end(); } catch {}
  }
  legacySseClients.clear();
  try { httpServer.close(); } catch {}
}
process.once('SIGINT', () => { shutdown(); process.exit(0); });
process.once('SIGTERM', () => { shutdown(); process.exit(0); });
process.once('exit', shutdown);
