/*!
 * Hx0 jQuery Lite fallback.
 * A small offline compatibility layer for common Tampermonkey scripts that only need
 * selector, traversal, events, attributes, style, and simple DOM helpers.
 */
(function (g) {
  'use strict';
  if (g.jQuery && g.$) return;

  function isArrayLike(x) {
    return x && typeof x !== 'string' && typeof x.length === 'number';
  }

  function toArray(input, context) {
    if (!input) return [];
    if (input instanceof Hx0Query) return input.toArray();
    if (typeof input === 'function') {
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', input, { once: true });
      else setTimeout(input, 0);
      return [];
    }
    if (typeof input === 'string') {
      var s = input.trim();
      if (!s) return [];
      if (s[0] === '<' && s[s.length - 1] === '>') {
        var box = document.createElement('template');
        box.innerHTML = s;
        return Array.prototype.slice.call(box.content.childNodes);
      }
      try {
        return Array.prototype.slice.call((context || document).querySelectorAll(s));
      } catch (e) {
        return [];
      }
    }
    if (input.nodeType || input === window || input === document) return [input];
    if (Array.isArray(input) || isArrayLike(input)) return Array.prototype.slice.call(input).filter(Boolean);
    return [input];
  }

  function refreshIndexes(obj, items) {
    var oldLen = obj.length || 0;
    for (var i = 0; i < oldLen; i++) delete obj[i];
    obj.items = items || [];
    obj.length = obj.items.length;
    for (var j = 0; j < obj.items.length; j++) obj[j] = obj.items[j];
    return obj;
  }

  function Hx0Query(input, context) {
    refreshIndexes(this, toArray(input, context));
  }

  Hx0Query.prototype.toArray = function () { return this.items.slice(); };
  Hx0Query.prototype.get = function (i) { return i == null ? this.toArray() : this.items[i < 0 ? this.items.length + i : i]; };
  Hx0Query.prototype.each = function (fn) {
    if (typeof fn !== 'function') return this;
    this.items.forEach(function (el, i) { fn.call(el, i, el); });
    return this;
  };
  Hx0Query.prototype.eq = function (i) { var el = this.get(i); return new Hx0Query(el ? [el] : []); };
  Hx0Query.prototype.first = function () { return this.eq(0); };
  Hx0Query.prototype.parent = function () {
    var out = [];
    this.each(function () { if (this.parentElement && out.indexOf(this.parentElement) < 0) out.push(this.parentElement); });
    return new Hx0Query(out);
  };
  Hx0Query.prototype.find = function (sel) {
    var out = [];
    this.each(function () { out = out.concat(toArray(sel, this)); });
    return new Hx0Query(out);
  };
  Hx0Query.prototype.on = function (types, handler, options) {
    if (typeof handler !== 'function') return this;
    String(types || '').split(/\s+/).filter(Boolean).forEach(function (type) {
      this.each(function () { this.addEventListener(type, handler, options || false); });
    }, this);
    return this;
  };
  Hx0Query.prototype.off = function (types, handler) {
    String(types || '').split(/\s+/).filter(Boolean).forEach(function (type) {
      this.each(function () {
        if (handler) this.removeEventListener(type, handler);
        else {
          var clone = this.cloneNode(true);
          if (this.parentNode) this.parentNode.replaceChild(clone, this);
        }
      });
    }, this);
    if (!handler && types) refreshIndexes(this, this.items.map(function (el) { return el.isConnected ? el : null; }).filter(Boolean));
    return this;
  };
  Hx0Query.prototype.click = function (handler) { return typeof handler === 'function' ? this.on('click', handler) : this.each(function () { this.click && this.click(); }); };
  Hx0Query.prototype.attr = function (name, value) {
    if (value === undefined) return this.items[0] && this.items[0].getAttribute ? this.items[0].getAttribute(name) : undefined;
    return this.each(function () { if (this.setAttribute) this.setAttribute(name, value); });
  };
  Hx0Query.prototype.removeAttr = function (name) { return this.each(function () { if (this.removeAttribute) this.removeAttribute(name); }); };
  Hx0Query.prototype.css = function (name, value) {
    if (typeof name === 'object') {
      var styles = name;
      return this.each(function () { for (var k in styles) this.style[k] = styles[k]; });
    }
    if (value === undefined) return this.items[0] ? getComputedStyle(this.items[0])[name] : undefined;
    return this.each(function () { this.style[name] = value; });
  };
  Hx0Query.prototype.val = function (value) {
    if (value === undefined) return this.items[0] && 'value' in this.items[0] ? this.items[0].value : undefined;
    return this.each(function () { if ('value' in this) this.value = value; });
  };
  Hx0Query.prototype.text = function (value) {
    if (value === undefined) return this.items.map(function (el) { return el.textContent || ''; }).join('');
    return this.each(function () { this.textContent = value; });
  };
  Hx0Query.prototype.html = function (value) {
    if (value === undefined) return this.items[0] ? this.items[0].innerHTML : undefined;
    return this.each(function () { this.innerHTML = value; });
  };
  Hx0Query.prototype.append = function (child) {
    var nodes = toArray(child);
    return this.each(function () {
      var parent = this;
      nodes.forEach(function (node, i) { parent.appendChild(i ? node.cloneNode(true) : node); });
    });
  };
  Hx0Query.prototype.remove = function () { return this.each(function () { if (this.parentNode) this.parentNode.removeChild(this); }); };
  Hx0Query.prototype.offset = function () {
    var el = this.items[0];
    if (!el || !el.getBoundingClientRect) return { top: 0, left: 0 };
    var r = el.getBoundingClientRect();
    return { top: r.top + (window.pageYOffset || document.documentElement.scrollTop || 0), left: r.left + (window.pageXOffset || document.documentElement.scrollLeft || 0) };
  };
  Hx0Query.prototype.width = function () { var el = this.items[0]; return el ? el.getBoundingClientRect().width : 0; };
  Hx0Query.prototype.height = function () { var el = this.items[0]; return el ? el.getBoundingClientRect().height : 0; };
  Hx0Query.prototype.is = function (sel) {
    var el = this.items[0];
    if (!el) return false;
    if (sel === ':visible') {
      var st = getComputedStyle(el);
      return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0' && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    }
    try { return el.matches(sel); } catch (e) { return false; }
  };

  function $(input, context) { return new Hx0Query(input, context); }
  $.fn = Hx0Query.prototype;
  $.each = function (obj, fn) {
    if (!obj || typeof fn !== 'function') return obj;
    if (Array.isArray(obj) || isArrayLike(obj)) {
      for (var i = 0; i < obj.length; i++) if (fn.call(obj[i], i, obj[i]) === false) break;
    } else {
      for (var k in obj) if (Object.prototype.hasOwnProperty.call(obj, k) && fn.call(obj[k], k, obj[k]) === false) break;
    }
    return obj;
  };
  $.extend = function (target) {
    target = target || {};
    for (var i = 1; i < arguments.length; i++) {
      var src = arguments[i] || {};
      for (var k in src) if (Object.prototype.hasOwnProperty.call(src, k)) target[k] = src[k];
    }
    return target;
  };
  $.trim = function (s) { return String(s == null ? '' : s).trim(); };
  $.isArray = Array.isArray;

  g.jQuery = g.$ = $;
})(typeof globalThis !== 'undefined' ? globalThis : window);
